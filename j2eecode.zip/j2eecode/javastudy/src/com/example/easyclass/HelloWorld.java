// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.easyclass;
public class HelloWorld {
	public void printContent(){
		System.out.println("Hello World!!!");
	}
	public static void main(String[] args) {
		HelloWorld helloWorld = new HelloWorld();
		helloWorld.printContent();
	}
   }