// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.regex;

public class REOne {

	public static void main(String[] args) {
		String regex1="[a-z]";
		String regex2="[^a-z]";
		String regex3="[a-z&&[^bc]]";
		String regex4="\\d";	
		String regex5="\\D"; 	
		String regex6="\\s"; 	
		String regex7="\\S"; 	
		String regex8="\\w"; 	
		String regex9="\\W"; 	

		System.out.println("a".matches(regex1));	//true
		System.out.println("b".matches(regex2));	//false
		System.out.println("f".matches(regex3));	//true
		System.out.println("b".matches(regex3));	//false
		System.out.println("1".matches(regex4));	//true
		System.out.println("1".matches(regex5));	//false
		System.out.println(" ".matches(regex6));	//true
		System.out.println(" ".matches(regex7));	//false
		System.out.println("_".matches(regex8));	//true
		System.out.println("_".matches(regex9));	//false
	}
}
