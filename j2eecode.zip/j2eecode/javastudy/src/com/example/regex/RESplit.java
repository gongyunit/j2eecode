// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.regex;

public class RESplit {

	public static void main(String[] args) {
		String lable = "aa。111。name。yy@126。1aa。111";
		
		//正则表达式解释：以句号开头跟零个或者多个空白进行组合
		String regex = "。\\s*";
		String[] temp = lable.split(regex);
		for(String one:temp){
			System.out.println(one);
		}
	}
}
