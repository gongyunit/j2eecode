// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.regex;

public class REtwo {

	public static void main(String[] args) {
		String regex1="(cn){2}";
		String regex2="[a-z]{2,}";
		String regex3="[0-9]{3,5}";
		System.out.println("cncn".matches(regex1));	//true
		System.out.println("ab".matches(regex2));	//true
		System.out.println("a".matches(regex2));	//false
		System.out.println("123".matches(regex3));	//true
		System.out.println("12".matches(regex3));	//false
	}
}
