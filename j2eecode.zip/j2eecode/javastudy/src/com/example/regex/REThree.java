// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.regex;

public class REThree {

	public static void main(String[] args) {
		String regex1="[0-9]*";
		String regex2="(cn)+";
		String regex3="@?";
		System.out.println("".matches(regex1));	//true
		System.out.println("333".matches(regex1));	//true
		System.out.println("cn".matches(regex2));	//true
		System.out.println("chln".matches(regex2));	//false
		System.out.println("@@@".matches(regex3));	//false
		System.out.println("@".matches(regex3));	//true
		System.out.println("".matches(regex3));	//true

	}
}
