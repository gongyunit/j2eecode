// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.regex;

public class REMatches {

	public static void main(String[] args) {
		String emailRegEx="^[a-zA-Z0-9_.-]+@([a-zA-Z0-9-]+\\.)+(cn)$";
		String email="Z93@369.net.com.cn";
		System.out.println(email.matches(emailRegEx));
	}
}
