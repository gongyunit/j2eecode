// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.regex;

public class REReplaceALL {

	public static void main(String[] args) {
		//将str中的china换成“中国”二字
		String str="hello china";
		str=str.replaceAll("china","中国");
		System.out.println(str);

	}
}
