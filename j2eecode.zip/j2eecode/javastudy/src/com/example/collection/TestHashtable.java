// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.collection;

import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class TestHashtable {

	public static void main(String[] args) {
		Map map = new Hashtable();
		
		//put方法，给map赋值
		map.put(1, "aa");
		map.put(2, "bb");
		map.put(3, "cc");
		//size方法查看map的键值对的个数
		System.out.println(map.size());
		
		//contains的相关方法，查看map的key或者value中是否包含指定的值
		System.out.println(map.containsKey(2));
		System.out.println(map.containsValue("bb"));
		
		//访问map的所有的key值
		Set keys = map.keySet();
		for(Object key : keys){
			System.out.println(key);
		}
		//访问map的所有的vulue值
		Collection c = map.values();
		for(Object value:c){
			System.out.println(value);
		}
		//遍历map方法一：访问map的每一个key和value，通过entrySet，效率最高		
		Iterator iter = map.entrySet().iterator(); 
		while (iter.hasNext()) { 
		    Map.Entry entry = (Map.Entry) iter.next(); 
		    Object key = entry.getKey(); 
		    Object val = entry.getValue(); 
		} 
		//遍历map方法二：访问map的每一个key和value，通过keyset，效率低
		Iterator iter2 = map.keySet().iterator(); 
		while (iter2.hasNext()) { 
		    Object key = iter2.next(); 
		    Object val = map.get(key); 
		}
		//删除指定key值的键值对
		map.remove(2);
		System.out.println(map.size());
		//清空map的所有值
		map.clear();
		System.out.println(map.size());
	}
}
