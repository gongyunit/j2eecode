// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.collection;

import java.util.ArrayList;
import java.util.List;

public class TestList {

	public static void main(String[] args) {
		List list = new ArrayList();//初始化List集合
		list.add('a');//add方法，增加字符型元素
		list.add('b');
		list.add('c');
		
		System.out.println(list.get(0));//获取第一个元素，从0开始，返回值是a
		System.out.println(list.contains('a'));//集合中是否包含元素a，返回值是true
		System.out.println(list.indexOf('a'));//元素a在集合中的位置，返回值是0
		
		list.set(0, 'n');//将第一个元素更改为n
		System.out.println(list.get(0));//更改后，得到第一个元素的值成为了a
		
		System.out.println(list.isEmpty());//判断list集合是否为空，返回值是false
		System.out.println(list.size());//返回list集合的大小，返回值是3
		
		List newList = list.subList(0, 2);//截取元素，从第一个到第二个，不包括第三个。
		System.out.println(newList.size());//新集合的大小是1
		
		newList.clear();//新集合清空所有元素
		System.out.println(newList.isEmpty());//新集合清空后为空
	}
}
