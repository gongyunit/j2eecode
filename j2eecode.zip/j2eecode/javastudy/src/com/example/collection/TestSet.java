// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.collection;

import java.util.HashSet;
import java.util.Set;

public class TestSet {

	public static void main(String[] args) {
		Set set = new HashSet();
		
		set.add('a');//add方法，增加字符型元素
		set.add('b');
		set.add('c');
		
		System.out.println(set.contains('a'));//集合中是否包含元素a，返回值是true
		System.out.println(set.isEmpty());//判断set集合是否为空，返回值是false
		System.out.println(set.size());//返回set集合的大小，返回值是3
		set.clear();//新集合清空所有元素
		System.out.println(set.isEmpty());//新集合清空后,返回值是空。
		
	}
}
