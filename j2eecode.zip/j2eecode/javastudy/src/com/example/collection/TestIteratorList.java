// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class TestIteratorList {

	public static void main(String[] args) {
		List<String> list = new ArrayList<String>();
		list.add("dd");
		list.add("ee");

		System.out.println("list当前的长度："+list.size());
		
		Iterator<String> it = list.iterator();
		while(it.hasNext()){
			String temp = it.next();
			System.out.println(temp);
			if(temp.equals("dd")){
				it.remove();
			}
		}
		System.out.println("list删除之后的长度："+list.size());
	}
}
