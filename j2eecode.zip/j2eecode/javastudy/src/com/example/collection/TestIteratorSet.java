// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.collection;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class TestIteratorSet {

	public static void main(String[] args) {

		Set<String> set = new HashSet<String>();
		set.add("dd");
		set.add("ee");

		System.out.println("set当前的长度："+set.size());
		
		Iterator<String> it = set.iterator();
		while(it.hasNext()){
			String temp = it.next();
			System.out.println(temp);
			if(temp.equals("dd")){
				it.remove();
			}
		}
		System.out.println("set删除之后的长度："+set.size());
	
	}
}
