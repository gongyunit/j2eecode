// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.collection;

import java.util.HashSet;
import java.util.Set;

public class TestBigFor {

	public static void main(String[] args) {
		Set<String> sets = new HashSet<String>();
		sets.add("tt");
		sets.add("nn");
		
		for(String str: sets){//增强型for
			System.out.println(str);
		}
	}
}
