// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.yunsuan;

public class YunLuoJi {

		public static void main(String[] args) {
			int one = 3;
			int two = 7;
			
			System.out.println((one!=two)&&(one<two));//输出为true
			System.out.println((one!=two)||(one>two));//输出为true
			System.out.println(!(one<two));//输出为false
			
			//短路逻辑
			System.out.println((one==two)&&(one<two));//输出为false
			System.out.println((one!=two)||(one>two));//输出为true
		}
}
