// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.yunsuan;

public class YunSuanshu {

	public static void main(String[] args) {
		int one =6, two=15;
		int d1= one++;	//先将one的值赋给d1,然后one再自加
		int d2= ++two;	//先将two的值自加，然后再赋给d2
		System.out.println(one);//输出值为7
		System.out.println(two);//输出值为16
		System.out.println(d1);//输出值为6
		System.out.println(d2);//输出值为16
		
	}
}
