// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.yunsuan;

public class YunGuanXi {

	public static void main(String[] args) {
		int one = 9;
		int two = 5;
		
		System.out.println(one == two);//输出为false
		System.out.println(one != two);//输出为true
		System.out.println(one > two);//输出为true
		System.out.println(one < two);//输出为false
		System.out.println(one >= two);//输出为true
		System.out.println(one <= two);//输出为false
	}
	
}
