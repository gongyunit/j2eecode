// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.yunsuan;

public class YunWei {

	public static void main(String[] args) {
		int A = 12;
		int B = 13;
		
		System.out.println(A&B);
		System.out.println(A | B);
		System.out.println(A^B);
		System.out.println(~A);
		System.out.println(A<<2);
		System.out.println(A>>2);
		System.out.println(A>>>2);
		
	}
}
