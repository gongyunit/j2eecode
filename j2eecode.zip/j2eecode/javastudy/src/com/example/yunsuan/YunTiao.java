// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.yunsuan;

public class YunTiao {

	public static void main(String[] args) {
		int a = 5;
		int b = 6;
		
		int score;
		
		score = a>b? 15:16;
		
		System.out.println(score);//输出结果为16
	}
}
