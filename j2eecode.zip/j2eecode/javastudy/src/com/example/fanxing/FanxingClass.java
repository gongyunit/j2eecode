// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.fanxing;

//类声明泛型
public class FanxingClass<A> {

	//此方法应用泛型是，就不用再void之前声明了，因为类上边已经声明
	public void printData(A number){
		System.out.println(number);
	}
	
	public static void main(String[] args) {
		FanxingClass fc = new FanxingClass();
		//因为用了泛型，printData方法既可以支持字符串类型，也支持int类型的数据
		fc.printData("dd");
		fc.printData(11);
	}
}
