// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.fanxing;

import java.util.ArrayList;

public class FanxingList {

	public static void main(String[] args) {
		//集合初始化时指定泛型类型是String
		ArrayList<String> al =  new ArrayList<String>();
		al.add("aa");
		al.add("bb");
//		al.add(1);//编译报错，因为泛型中已经指定为String类型
		
	}
}
