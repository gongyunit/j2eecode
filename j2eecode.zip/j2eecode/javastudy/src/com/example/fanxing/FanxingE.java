// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.fanxing;

public class FanxingE {

	public <A> void printArray(A[] oneArray){
		for(A a:oneArray){
			System.out.println(a);
		}
	}
	
	public static void main(String[] args) {
		FanxingE fe = new FanxingE();
		
		String[] name = {"aa","bb"};
		Integer[] number = {1,2};
		
		//通过泛型，printArray可以传递不同类型的数组对象，而不用更改参数
		System.out.println("传递字符串数组类型");
		fe.printArray(name);
		System.out.println("传递整型数组类型");
		fe.printArray(number);
	}
}
