// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.exception;

public class MyExceptionTest {

	public void testExce() throws MyException{
		throw new MyException(3);
	}
	
	public static void main(String[] args) {
		MyExceptionTest met = new MyExceptionTest();
		try {
			met.testExce();
		} catch (MyException e) {
			System.out.println(e.getCount());
		}
	}
}
