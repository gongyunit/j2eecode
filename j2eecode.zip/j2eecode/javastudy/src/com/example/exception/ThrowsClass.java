// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.exception;


public class ThrowsClass {

	public void add(int count) throws NoSuchFieldException
	{
		System.out.println("throws ");
		
	}
	
	public static void main(String[] args) {
		ThrowsClass tsc = new ThrowsClass();
		
		try {
			tsc.add(2);//对于用throws签名的方法，必须进行异常处理。
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		}
	}
}
