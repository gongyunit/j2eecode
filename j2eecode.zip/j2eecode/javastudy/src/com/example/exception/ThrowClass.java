// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.exception;

public class ThrowClass {
	
	public void throwexc(){
		String name = null;
		
		try {
			System.out.println(name.length());
		} catch (Exception e) {
			throw new NullPointerException();//通过关键在throw捕获之后再抛出空指针异常，让上层来接收处理
		}
	}

	public static void main(String[] args) {
		ThrowClass tc = new ThrowClass();
		try {
			tc.throwexc();//捕获抛出的异常之后，进行针对性处理
		} catch (Exception e) {
			System.out.println("main deal it");
		}
	}
}
