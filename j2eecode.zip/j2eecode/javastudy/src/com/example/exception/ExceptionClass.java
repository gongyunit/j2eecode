// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.exception;

public class ExceptionClass {

	public static void main(String[] args) {
		String name = null;
		
		try {
			//抛出空指针异常
			System.out.println(name.length());
		} catch (NullPointerException e) {
			e.printStackTrace();//异常的常用方法，控制台打印异常栈
			System.out.println(e.getMessage());//异常的常用方法，获取异常的信息
		}finally{
			System.out.println("the end");//finally中的语句一定且在最后执行
		}
	}
}
