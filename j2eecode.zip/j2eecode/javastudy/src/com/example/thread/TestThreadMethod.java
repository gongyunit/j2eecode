// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.thread;

public class TestThreadMethod extends Thread {

	public void run(){
		//死循环
		while(true){
			System.out.println("hello");
		}
	}
	
	public static void main(String[] args) {
		TestThreadMethod ttm = new TestThreadMethod();
		//设置为守护线程，ttm线程的run方法虽然为死循环方法，但是当main方法的sleep执行3秒之后执行完，自动就结束了，如果不设置，则死循环会一直执行
		ttm.setDaemon(true);
		ttm.start();
		
		try {
			//线程休眠3秒
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
