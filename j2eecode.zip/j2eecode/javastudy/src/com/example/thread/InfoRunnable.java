// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.thread;

public class InfoRunnable implements Runnable{

	@Override
	public void run() {
		System.out.println("success");
		//获取当前线程的名字，输出为Thread-0
		System.out.println(Thread.currentThread().getName());
	}
	
	public static void main(String[] args) {
		//先创建继承Runnable接口的对象
		InfoRunnable ir = new InfoRunnable();
		//将该对象放入到Thread中
		Thread t = new Thread(ir);
		//默认会调用run方法，最后的输出是success
		t.start();
		//获取当前线程的名字，输出为main，因为在main方法中
		System.out.println(Thread.currentThread().getName());
	}
}
