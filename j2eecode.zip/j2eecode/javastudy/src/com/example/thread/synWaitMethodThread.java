// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.thread;

 public class synWaitMethodThread extends Thread {
     private Object lock;
 
     public synWaitMethodThread(Object lock) {
         super();
         this.lock = lock;
     }
 
     @Override
     public void run() {
         Task service = new Task();
         service.testWaitMethod(lock);
     }
 }
