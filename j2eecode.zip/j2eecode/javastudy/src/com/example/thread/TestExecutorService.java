// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.thread;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TestExecutorService {

    public static void main(String[] args){   
      //4种创建线程池的方式
      ExecutorService executorService = Executors.newCachedThreadPool();   
      ExecutorService executorService2 = Executors.newFixedThreadPool(5);  
      ExecutorService executorService3 = Executors.newScheduledThreadPool(5);
      ExecutorService executorService4 = Executors.newSingleThreadExecutor();  

      //以newCachedThreadPool为例，讲解如何使用线程池的实例
        for (int i = 0; i < 2; i++){   
            executorService.execute(new Runnable(){
                public void run(){   
                    System.out.println(Thread.currentThread().getName() + "被执行");   
                } 
            });   
        }   
        
        //线程池使用完之后，需要关闭
        executorService.shutdown();   
    }   
}   
  
