// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.thread;

public class TaskThread extends Thread {

	//重写run方法
	public void run(){
		System.out.println("hello world!");
	}
	
	public static void main(String[] args) {
		TaskThread tt = new TaskThread();
		//调用start（）方法启动线程。默认调用重写的run方法。
		tt.start();
		//设置线程的优先级为最高
		tt.setPriority(10);
	}
}
