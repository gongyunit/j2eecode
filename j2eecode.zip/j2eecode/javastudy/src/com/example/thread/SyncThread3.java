// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.thread;

class SyncThread3 implements Runnable {
	   private static int number;

	   public SyncThread3() {
		   number = 0;
	   }
	   
	   public  void method() {
		 //synchronized关键字修饰类，SyncThread3的同步的作用范围是：SyncThread3的所有对象
		   synchronized(SyncThread3.class){
		      for (int i = 0; i < 3; i ++) {
			         try {
			            System.out.println(Thread.currentThread().getName() + ":" + (number++));
			            Thread.sleep(200);
			         } catch (Exception e) {
			            e.printStackTrace();
			         }
			      }			   
		   }

	   }

	   public synchronized void run() {
	      method();
	   }
	   public static void main(String[] args) {
		   SyncThread3 syncThread31 = new SyncThread3();
		   SyncThread3 syncThread32 = new SyncThread3();
		   Thread thread1 = new Thread(syncThread31, "Thread1");
		   Thread thread2 = new Thread(syncThread32, "Thread2");
		   thread1.start();
		   thread2.start();
	}
}