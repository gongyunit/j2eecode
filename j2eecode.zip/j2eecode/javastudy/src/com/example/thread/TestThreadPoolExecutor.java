// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.thread;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class TestThreadPoolExecutor {
	public static void main(String[] args){   
        //创建数组型缓冲等待队列   
        BlockingQueue<Runnable> bq = new ArrayBlockingQueue<Runnable>(10);   
        //ThreadPoolExecutor：创建自定义线程池，池中保存的线程数为3，允许的最大线程数为6  
        ThreadPoolExecutor tpe = new ThreadPoolExecutor(3,6,50,TimeUnit.MILLISECONDS,bq);   
        
        //创建三个任务   
        Runnable t1 = new TempThread();   
        Runnable t2 = new TempThread();   
        Runnable t3 = new TempThread();   
        //每个任务会在一个线程上执行  
        tpe.execute(t1);   
        tpe.execute(t2);   
        tpe.execute(t3);   
        
        //关闭自定义线程池   
        tpe.shutdown();   
    }   
}   
  

class TempThread implements Runnable{   
    @Override   
    public void run(){   
        System.out.println(Thread.currentThread().getName() + "被执行！");   
        try{   
            Thread.sleep(200);   
        }catch(Exception e){   
            e.printStackTrace();   
        }   
    }   
}