// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.thread;

 public class TestWaitAndNotify {
 
     public static void main(String[] args) {
 
         Object lock = new Object();
 
         synWaitMethodThread swt = new synWaitMethodThread(lock);
         swt.start();
 
         synNotifyMethodThread snt = new synNotifyMethodThread(lock);
         snt.start();
     }
 }
