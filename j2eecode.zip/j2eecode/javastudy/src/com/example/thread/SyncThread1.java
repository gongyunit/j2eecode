// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.thread;

class SyncThread1 implements Runnable {
	   private static int number;

	   public SyncThread1() {
		   number = 0;
	   }
	   
	   public  void run() {
		 //synchronized关键字修饰代码块
		   synchronized(this){
		         for (int i = 0; i < 3; i++) {
			            try {
			               System.out.println(Thread.currentThread().getName() + ":" + (number++));
			               Thread.sleep(200);
			            } catch (Exception e) {
			               e.printStackTrace();
			            }
			         }   
		   }

	   }
	   
//	   //synchronized关键字修饰方法
//	   public synchronized void run() {
//	         for (int i = 0; i < 3; i++) {
//	            try {
//	               System.out.println(Thread.currentThread().getName() + ":" + (number++));
//	               Thread.sleep(200);
//	            } catch (Exception e) {
//	               e.printStackTrace();
//	            }
//	         }
//	   }

	   
	public static void main(String[] args) {
		SyncThread1 syncThread1 = new SyncThread1();
		Thread thread1 = new Thread(syncThread1, "Thread1");
		Thread thread2 = new Thread(syncThread1, "Thread2");
		thread1.start();
		thread2.start();	
	}
}
