// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.thread;

public class TestJoin {

	public static void main(String[] args) {
	      Thread t = new Thread(new Runnable()
	         {
	            public void run()
	            {
	               System.out.println("one task started");
	               System.out.println("Sleeping for 3seconds");
	               try
	               {
	                  Thread.sleep(3000);
	               } catch (InterruptedException e)
	               {
	                  e.printStackTrace();
	               }
	               System.out.println("one task completed");
	            }
	         });
	      Thread t1 = new Thread(new Runnable()
	         {
	            public void run()
	            {
	               System.out.println("two task completed");
	            }
	         });
	      t.start(); 
	      try {
			t.join();
		} catch (Exception e) {
			e.printStackTrace();
		} 
	      t1.start();
	   }
	}
