// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.thread;

class SyncThread2 implements Runnable {
	   private static int number;

	   public SyncThread2() {
		   number = 0;
	   }

	   //synchronized关键字修饰静态方法
	   public synchronized static void method() {
	      for (int i = 0; i < 3; i ++) {
	         try {
	            System.out.println(Thread.currentThread().getName() + ":" + (number++));
	            Thread.sleep(200);
	         } catch (Exception e) {
	            e.printStackTrace();
	         }
	      }
	   }

	   public synchronized void run() {
	      method();
	   }
	   public static void main(String[] args) {
		   SyncThread2 syncThread21 = new SyncThread2();
		   SyncThread2 syncThread22 = new SyncThread2();
		   Thread thread1 = new Thread(syncThread21, "Thread1");
		   Thread thread2 = new Thread(syncThread22, "Thread2");
		   thread1.start();
		   thread2.start();
	}
}
