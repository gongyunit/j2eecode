// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.thread;

 public class Task {

	 //wait任务，即：该方法的目的是通过调用wait（）方法释放自己持有的锁
	 public void testWaitMethod(Object lock) {
	      try {
	          synchronized (lock) {
	          System.out.println("begin wait() ThreadName="+ Thread.currentThread().getName());
	          lock.wait();
	          System.out.println("  end wait() ThreadName="+ Thread.currentThread().getName());
	             }
	         } catch (Exception e) {
	             e.printStackTrace();
	         }
	     }
	//notify任务，即：该方法的目的是通过调用notify（）方法唤醒对象锁
	  public void testNotifyMethod(Object lock) {
	         try {
	             synchronized (lock) {
	                 System.out.println("begin notify() ThreadName="+ Thread.currentThread().getName() );
	                 lock.notify();
	                 Thread.sleep(3000);
	                 System.out.println("  end notify() ThreadName="+ Thread.currentThread().getName() );
	             }
	     } catch (Exception e) {
	         e.printStackTrace();
	     }
	 }
 }
