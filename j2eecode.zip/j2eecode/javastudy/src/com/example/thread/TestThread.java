// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.thread;

public class TestThread {

	public static void main(String[] args) {
		Thread td = new Thread("name1");
		td.start();
		System.out.println(td.getId());
		System.out.println(td.getPriority());
		System.out.println(td.getName());
		System.out.println(td.getState());
		System.out.println(td.isAlive());
		System.out.println(td.isDaemon());
		System.out.println(td.isInterrupted());
	}
}
