// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.var;

public class DataType {

	public static void main(String[] args) {
		byte bt = 120;
		System.out.println(bt);
		
		short st = 32700;
		System.out.println(st);
		
		int two=529;	//10进制
		int three=0x347a;	//16进制
		int four=030;	//8进制
		System.out.println(two);
		System.out.println(three);
		System.out.println(four);
		
		int data1 = 49;
		int data2 = 79;
		int dataT = data1/data2;
		System.out.println(dataT);
		
		int number=2147483647;
		int score=-2147483648;
		number= number+1;//结果为-2147483648
		score = score -1; //结果为2147483647
		System.out.println(number);
		System.out.println(score);
		
		long gg= 44L;//正确		
		long yy = 3147483647L;
		System.out.println(yy);
		
		double tt = 4.7;
		System.out.println(tt);

		char cr1= 705;
		char cr2='N';
		char cr3='\u0031';
		System.out.println(cr3);
		
		int a = 9;
		int b = 10;
		Boolean isBig = b>a;
		System.out.println(isBig);

		int onef=654;
		int twof=957;
		long threef= onef + twof;	//自动将int转换为long
		long numberf=9967L;
		int af=(int) numberf;	//需要强制转换符，由于9967在int范围内，没有产生溢出
		long scoref = 5147483647L;
		int bf=(int) scoref;		//会产生溢出，结果为0
		System.out.println(scoref);
		
		double ttf=7.55684954444444444;
		float rrf=(float) ttf;		//会造成精度的损失，结果为7.5568495
		System.out.println(rrf);
	}
	
}
