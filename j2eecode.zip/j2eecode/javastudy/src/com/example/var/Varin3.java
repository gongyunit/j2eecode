// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.var;

public class Varin3 {
	
//	public static void main(String[] args) {
//		
//		double data = 5;//编译正确，声明时将变量data初始化
//		int one,two=56;
//		int three=one+two; //编译错误，变量one没有初始化
//	}
}
