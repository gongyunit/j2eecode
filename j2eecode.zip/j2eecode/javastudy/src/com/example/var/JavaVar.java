// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.var;

public class JavaVar {
	
	//name就是成员变量
	public String name; 
	//money就是静态的私有变量
	private static double money;
	
	public void countNum(){
		//first就是局部变量
		int first = 1;
		System.out.println(first);
	}
	
	public static void main(String[] args) {
		JavaVar javavar = new JavaVar();
		javavar.countNum();
		
		double tt=7.55684954444444444;
		float rr=(float) tt;	
		System.out.println(rr);
	}
}
