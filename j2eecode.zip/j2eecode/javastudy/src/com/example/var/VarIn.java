// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.var;

public class VarIn {

	public static void main(String[] args) {
		
		int one = 4,two = 9 ;//声明了两个整型变量one赋值为4，two赋值为9
				
		int three,four = 5 ;//声明了两个整型变量three没有赋值，four赋值为5
		
		
		
	}
}
