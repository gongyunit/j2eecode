// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.var;

public class Varin2 {

//	public static void main(String[] args) {
//		int 456oher = 56; //编译错误，不能以数字开头。
//	 	int 数据 = 60; //编译正确，不建议使用。
//		int continue = 200; //编译错误，java保留字。
//
//		int data = 80;
//		System.out.println(Data); //编译错误，大小写敏感
//		
//		double coureSocre;//见名知意，且首字母小写，其他字母大写
//
//	}
}
