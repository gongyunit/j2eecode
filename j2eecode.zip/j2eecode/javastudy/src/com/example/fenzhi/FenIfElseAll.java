// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.fenzhi;

public class FenIfElseAll {

	public static void main(String[] args) {
		int a = 9 ;
		int b = 6;
		int c = 0;
		
		if(a == b){
			c = 1;
		}else if(a<b){
			c = 2;
		}
		else if(a > b){
			c = 3;
		}else{
			c = 99;
		}
		
		System.out.println(c);//输出为3，因为第二个else if中的表达式为true；
	}
}
