// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.fenzhi;

public class FenFor {

	public static void main(String[] args) {
		
		int a = 5;
		for(int i = 3; i<5; i++){
			System.out.println(i);
		}
		
	}
}
