// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.fenzhi;

public class FenDoWhile {
	public static void main(String[] args) {
		
		int a = 6;
		
		do{
			System.out.println(a);
			a++;
		}while(a<6);
			
		
	}
}
