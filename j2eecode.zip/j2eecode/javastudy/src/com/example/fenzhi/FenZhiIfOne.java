// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.fenzhi;

public class FenZhiIfOne {

	public static void main(String[] args) {
		int a = 2;
		int b = 6;
		int c = 1;
		if(a<b){
			c = 9;
		}else{
			c = 5;
		}
		
		System.out.println(c);//输出9，因为if表达式为true
	}
}
