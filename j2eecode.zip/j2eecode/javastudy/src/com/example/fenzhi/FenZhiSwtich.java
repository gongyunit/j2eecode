// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.fenzhi;

public class FenZhiSwtich {

	public static void main(String[] args) {
		int a = 2;
		
		switch(a){
		
		case 1:
			System.out.println("hao");
			break;
		case 2:
			System.out.println("henhao");//最后输出这个代码块，因为表达式中的值跟这个case后边的整型值相同
			break;
		case 3:
			System.out.println("xiangdanghao");
			break;
		default:
			System.out.println("yiban");
			
		}
	}
}
