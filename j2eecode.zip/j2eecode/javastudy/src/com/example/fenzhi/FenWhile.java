// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.fenzhi;

public class FenWhile {

	public static void main(String[] args) {
	
		int a = 6;
		
		while(a<8){
			System.out.println(a);
			a++;
		}
	}
}
