// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.objects;

public class OBEquals {

	public static void main(String[] args) {
		String s1,s2,s3 = "abc", s4 ="abc" ;
		s1 = new String("abc");
		s2 = new String("abc");
		
		System.out.println(s1==s2);//false,原因：两个变量的内存地址不一样，也就是说它们指向的对象不 一样
		System.out.println(s1.equals(s2));//true,原因：两个变量的所包含的内容是abc，故相等。
	}
}
