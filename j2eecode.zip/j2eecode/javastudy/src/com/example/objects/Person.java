// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.objects;

public class Person {
	
	private String name;
	private int age;
	
	public Person(String name,int age){
		this.name = name;
		this.age = age;
	}
	
	//重写toString方法，格式：类名+N个属性值
	public String toString(){
		return "className="+this.getClass().getName()+"; name="+this.name+"; age="+this.age;
	}
	
	//重写equals方法，关键看斜边的第三个if
	public boolean equals(Object obj){
		if(obj==null){
			return false;
		}
		if(this==obj){
			return true;
		}
		if(obj instanceof Person){
			Person person=(Person)obj;
			return person.name==this.name&&person.age==this.age;
		}else{
			return false;
		}
	}

	
	public static void main(String[] args) {
		Person p = new Person("hong",21);
		System.out.println(p.toString());
		
		Person p2 = new Person("hong",21);
		System.out.println(p.equals(p2));
	}
}	
