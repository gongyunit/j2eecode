// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.objects;

public class Animal {

	private String name;
	private int age;
	
	public Animal(String name,int age){
		this.name = name;
		this.age = age;
	}
	
	public boolean equals(Object obj){
		if(obj instanceof Animal){
			Animal animal=(Animal)obj;
			return animal.name==this.name&&animal.age==this.age;
		}else{
			return false;
		}
	}
	
	public static void main(String[] args) {
		Animal a = new Animal("xing",5);
		Animal a2 = new Animal("xing",5);
		System.out.println(a.equals(a2));//true,重写了equals方法
		System.out.println(a==a2);//false，==比较的是地址值，而不是像equals方法，因此是false
	}
}
