// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.javaclass;

public class SimpleClass {

	public String name ;
	public int number;
	
	public static void main(String[] args) {
		//创建对象
		SimpleClass simpleClass = new SimpleClass();
	}
	
}
