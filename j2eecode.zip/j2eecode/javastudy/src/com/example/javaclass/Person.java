// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.javaclass;

public class Person {//类名
	
	//定义了JavaClassBasic类的成员变量
	String name="xiaoniao";
	int age=6;
	String gender="nan";
	
	//定义了JavaClassBasic类的方法
	public void printInfo(Person person){
		System.out.println("name:" +person.name);
		System.out.println("age:" +person.age);
		System.out.println("gender:" +person.gender);
	}
	
	public static void main(String[] args) {
		Person person = new Person();
		person.printInfo(person);
	}
}
