// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.javaclass;

public class Animal {

	public String name;
	public int age;
	
	public Animal(String name,int age){//类的构造函数
		this.name = name;
		this.age = age;
	}
	
	public static void main(String[] args) {
		Animal animal= new Animal("hailiang",3);//创建对象时，自动调用类的构造函数，进行类的初始化
		
		//因为已经初始化，因此，访问类的成员变量时，已经得到初值
		System.out.println(animal.name);
		System.out.println(animal.age);
		
	}
}
