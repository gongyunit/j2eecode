// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.javaclass;

public class NoGouZao {

	public String name;
	
	public void printInfo(){
		System.out.println("name");
	}
	
	public static void main(String[] args) {
		NoGouZao temp = new NoGouZao();
		temp.printInfo();
	}
}
