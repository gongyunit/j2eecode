// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.stream;

import java.io.Serializable;

public class Person implements Serializable{//继承Serializable接口，

	private static final long serialVerisionUID = 1L ; //设置序列化版本值
	
	private String name;
	
	private int age;
	
	private transient int number;//忽略不不劣化的属性，通过transient关键字

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
	
}
