// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.stream;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class TestFileInputStream1 {

	public static void main(String[] args) {
		try {
			// 通过构造函数（覆盖式），创建输出流和输入流。
			OutputStream fos = new FileOutputStream("./stream/fs/i.txt");
			InputStream fis = new FileInputStream("./stream/fs/o.txt");
			
			//实现文件复制，将o.txt文件中的内容读取出来，写入到i.txt文件中
			int temp = -1;
			while(( temp = fis.read())!=-1){
				fos.write(temp);
			}
			//文件处理完，要关闭
			fos.close();
			fis.close();
		} catch (Exception e) {
			
		}
	}
}
