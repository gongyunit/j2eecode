// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.stream;

import java.io.FileWriter;
import java.io.PrintWriter;

public class TestPrintWriter {

	public static void main(String[] args) {
		FileWriter fw = null;
		PrintWriter pw = null;
		try {
			//创建过滤流
			fw = new FileWriter("./stream/pw/o.txt");
			pw = new PrintWriter(fw,true);//增加一个true，代表PrintWriter将会自动刷新缓存
			
			pw.printf("世界：world");
			pw.println();
			pw.println("hello");
			pw.write("name:小鱼");
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
		
			try {
				pw.close();
				fw.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
