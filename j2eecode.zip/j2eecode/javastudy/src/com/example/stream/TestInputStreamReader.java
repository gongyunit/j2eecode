// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.stream;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;

public class TestInputStreamReader {

	public static void main(String[] args) {
		
		
		try {
			//创建输入流
			InputStream fis = new FileInputStream("./stream/isr/i.txt");
			//将字节流向字符流的转换。  
	        InputStreamReader isr = new InputStreamReader(fis);//读取 
	      //创建字符流缓冲区  
	        BufferedReader bufr = new BufferedReader(isr);//缓冲  
	        
	        //通过BufferedReader的readLine方法读取文件中的内容
	        String line = null;  
	        while((line = bufr.readLine())!=null){  
	            System.out.println(line);  
	        }  
	        
	        bufr.close();
	        isr.close();
	        fis.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
