// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.stream;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class TestObjectInputStream {

	public static void main(String[] args) {
		
		try {
			//创建对象输入流
			InputStream fis = new FileInputStream("./stream/os/i.txt");
			ObjectInputStream ois = new ObjectInputStream(fis);
			
			//将存储在文件中的对象反序列化出来
			Person one = (Person)ois.readObject();
			System.out.println(one.getAge());//反序列化之后，得到对象的age的值是11
			
			//将文件关闭，否则文件数据会出错
			fis.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
