// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.stream;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class TestFileInputStream2 {

	public static void main(String[] args) {
		try {
			// 通过构造函数（追加式），创建输出流和输入流。
			OutputStream fos = new FileOutputStream("./stream/fs/i.txt",true);
			InputStream fis = new FileInputStream("./stream/fs/o.txt");
			
			//通过批量读写，实现文件复制，将o.txt文件中的内容读取出来，追加写入到i.txt文件中
			byte[] b = new byte[1];
			int temp = -1;
			while(( temp = fis.read(b))!=-1){
				fos.write(b);
			}
			//文件处理完，要关闭
			fos.close();
			fis.close();
		} catch (Exception e) {
			
		}
	}
}
