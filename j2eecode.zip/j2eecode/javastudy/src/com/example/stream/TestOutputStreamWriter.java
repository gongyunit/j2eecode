// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.stream;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

public class TestOutputStreamWriter {

	public static void main(String[] args) {
		
//      OutputStream out = System.out;//打印到控制台。  
		try {
			OutputStream out = new FileOutputStream("./stream/isr/o.txt");
			//将字节流向字符流的转换。 
	        OutputStreamWriter osr = new OutputStreamWriter(out);//输出  
	      //创建字符流缓冲区  
	        BufferedWriter bufw = new BufferedWriter(osr);//缓冲  
	        
	        String str = "hello\r\nworld！";//要写入的内容
	        bufw.write(str);  
	        
	        bufw.flush();  
	        
	        bufw.close();  
	        osr.close();
	        out.close();
		} catch (Exception e) {
			e.printStackTrace();
		} 

	}
}
