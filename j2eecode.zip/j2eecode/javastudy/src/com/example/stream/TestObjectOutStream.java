// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.stream;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class TestObjectOutStream {

	public static void main(String[] args) {

		Person person = new Person();
		
		try {
			//创建对象输出流
			OutputStream fos = new FileOutputStream("./stream/os/i.txt");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			
			person.setAge(11);
			oos.writeObject(person);
			
			//将文件关闭，否则文件数据会出错
			fos.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	
	}
}
