// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.stream;

import java.io.InputStream;

public class ParentStream {

	public static void main(String[] args) {
		InputStream is = null;
	}
}
