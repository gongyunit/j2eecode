// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.xml;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
public class TestDomXml {
	//利用DOM方式生成xml文档
	public static void createXML(String outputPath) {  
        try {  
        	//建立Document对象，第一步：创建工厂DocumentBuilderFactory
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
            // 第二步：根据工厂创建DocumentBuilder  
            DocumentBuilder db = dbf.newDocumentBuilder();  
            // 第三步：利用DocumentBuilder创建xml的Document文档对象 
            Document xmlDocument = db.newDocument();  
            
            //建立xml的各个节点 ，创建根元素节点  
            Element rootEle = xmlDocument.createElement("whole");  
            // 创建一级子元素节点  
            Element childEle = xmlDocument.createElement("one");  
            //配置父子关系根节点和一级子节点
            rootEle.appendChild(childEle); 
            // 创建二级子元素节点  
            Element idEle = xmlDocument.createElement("id");  
            Element titleEle = xmlDocument.createElement("name");  
            //配置父子关系：一级子节点和二级子元素
            childEle.appendChild(idEle);  
            childEle.appendChild(titleEle); 
            // 创建文本节点  
            Text idText = xmlDocument.createTextNode("33");  
            Text titleText = xmlDocument.createTextNode("tree");  
            // 配置父子节点关系：二级子元素和文本节点 
            idEle.appendChild(idText);  
            titleEle.appendChild(titleText);  
            // rootEle是根节点，应该设置为xmlDocument的子节点  
            xmlDocument.appendChild(rootEle);  
  
            // 以下是将创建的xml文档输出，利用Transformer类，首先创建工厂  
            TransformerFactory tff = TransformerFactory.newInstance();  
            Transformer tf = tff.newTransformer();  
            // 包装要保存的xmlDocument  
            DOMSource source = new DOMSource(xmlDocument);  
            // 设置输出流  
            StreamResult sr = new StreamResult(new File(outputPath));  
            // 设置输出的属性  
            tf.setOutputProperty("encoding", "UTF-8");  
            // 输出  
            tf.transform(source, sr);  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
    }  
  
	//利用DOM方式解析xml文档
    public static void parseXML(String xmlPath) {  
        try {  
        	// 建立Document对象 
        	//第一步：创建工厂DocumentBuilderFactory
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
            // 第二步：根据工厂创建DocumentBuilder  
            DocumentBuilder db = dbf.newDocumentBuilder();  
            // 第三步：创建Document，形成树型结构  
            Document doc = db.parse(new File(xmlPath));  
            
            // 先取得根节点下的所有节点,"catalog"是自己定义的xml文件中的根节点 
            NodeList allNode = doc.getElementsByTagName("catalog");  
            // 循环取得每个node  
            for (int i = 0; i < allNode.getLength(); i++) {  
                Node data = allNode.item(i);  
                // 获取一级子节点的元素 
                NodeList firstChildNodes = data.getChildNodes();  
                for (int j = 0; j < firstChildNodes.getLength(); j++) {  
                    Node oneNode = firstChildNodes.item(j);  
                    //获取二级子节点的元素
                    NodeList secondeChildNodes = oneNode.getChildNodes();  
                    for (int t = 0; t < secondeChildNodes.getLength(); t++) {  
                        Node oneChildNode = secondeChildNodes.item(t);  
                        //判断节点的类型是否是元素类型ELEMENT_NODE  
                        if (oneChildNode.getNodeType() == Node.ELEMENT_NODE) {  
                        	//获取节点的名字是id，包含的文本内容
                            if("id".equals(oneChildNode.getNodeName())){
                                if(oneChildNode.hasChildNodes()) {  
                                    System.out.println(oneChildNode.getFirstChild().getNodeValue());  
                                }  
                            }  
                          //获取节点的名字是name，包含的文本内容
                            if("name".equals(oneChildNode.getNodeName())){
                                if(oneChildNode.hasChildNodes()) {  
                                    System.out.println(oneChildNode.getFirstChild().getNodeValue());  
                                }  
                            }  
                        }  
                    }  
                }  
            }  
        } catch (Exception e) {  
            e.printStackTrace();  
        } 
    }  
    public static void main(String[] args) {  
    	TestDomXml.createXML("./xmldoc/dom/a.xml");  
    	TestDomXml.parseXML("./xmldoc/dom/b.xml");  
    }  
}
