// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.xml;

import java.io.File;
import java.io.FileWriter;
import java.util.List;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

public class TestJDOMXml {
	 public static void createXML(String outputPath) {  
	        // 先建立Document对象  
	        Document doc = new Document();  
	        // 建立元素节点  
	        Element allEle = new Element("all");  
	        try {  
	            // 建立多个Element  
	            Element oneEle = new Element("one");  
	            Element idEle = new Element("id");  
	            Element nameEle = new Element("name");  
	            // 设置节点内容  
	            idEle.addContent("88");  
	            nameEle.addContent("bird");  
	            // 设置父子节点关系  
	            oneEle.addContent(idEle);  
	            oneEle.addContent(nameEle);  
	            allEle.addContent(oneEle);  
	            // 设置根节点  
	            doc.setRootElement(allEle);  
	  
	            // 使用IO流操作  
	            FileWriter writer = new FileWriter(new File(outputPath));  
	            // 定义输出对象  
	            XMLOutputter outputter = new XMLOutputter();  
	            // 设置编码  
	            Format f = Format.getPrettyFormat();  
	            f.setEncoding("UTF-8");//default=UTF-8  
	            outputter.setFormat(f);  
	            // 输出  
	            outputter.output(doc, writer);  
	            writer.close();  
	        } catch (Exception e) {  
	            e.printStackTrace();  
	        }  
	    }  
	  
	    public static void parseXML(String xmlPath) {  
	        //创建xml文档解析器
	        SAXBuilder builder = new SAXBuilder();  
	        try {  
	            Document doc = builder.build(new File(xmlPath));  
	            // 开始解析，取得根节点  
	            Element allEles = doc.getRootElement();  
	            // 取得指定元素的二级子节点  
	            List<Element> secondEles = allEles.getChildren("category"); 
	            //获取指定三级子节点
	            if(secondEles != null && secondEles.size()>0) {  
	                for(Element oneSecondEles:secondEles) {  
	                    Element id = oneSecondEles.getChild("id");  
	                    Element name = oneSecondEles.getChild("name");  
	                    System.out.println("id: "+id.getTextTrim() + "; name: " + name.getTextTrim());  
	                }  
	            }  
	        } catch (Exception e) {  
	            e.printStackTrace();  
	        } 
	    }  
	  
	    public static void main(String[] args) {  
	    	TestJDOMXml.createXML("./xmldoc/jdom/a.xml");  
	    	TestJDOMXml.parseXML("./xmldoc/jdom/b.xml"); 
	    }  
}
