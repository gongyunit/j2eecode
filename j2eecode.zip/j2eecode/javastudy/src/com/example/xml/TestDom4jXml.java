// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.xml;

import java.io.File;
import java.io.FileWriter;
import java.io.Writer;
import java.util.Iterator;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

public class TestDom4jXml {
	//创建dom4j模式下的xml文档
	public static void createXml(String fileName) {  
		//创建dom4j下的Document对象
        Document document = DocumentHelper.createDocument();  
        Element employees = document.addElement("all");  
        Element employee = employees.addElement("one");  
        Element id = employee.addElement("id");  
        id.setText("99");  
        Element name = employee.addElement("name");  
        name.setText("tree");  
        try {  
        	//将xml文件输出
            Writer fileWriter = new FileWriter(fileName);  
            XMLWriter xmlWriter = new XMLWriter(fileWriter);  
            xmlWriter.write(document);  
            xmlWriter.close();  
        } catch (Exception e) {  
        	e.printStackTrace();
        }  
    }  
  
	//解析dom4j模式下的xml文档
    public static void parserXml(String fileName) {  
        try {  
        	//创建dom4j下的xml文档解析器
        	 SAXReader saxReader = new SAXReader();  
            File inputXml = new File(fileName);  
            Document document = saxReader.read(inputXml);  
            //获取根节点元素
            Element rootEle = document.getRootElement();  
            //通过elementIterator（）方法获取二级孩子子节点元素
            for (Iterator i = rootEle.elementIterator(); i.hasNext();) {  
                Element secondEle = (Element) i.next();  
                
                //通过elementIterator（）方法获取三级孩子子节点元素
                for (Iterator j = secondEle.elementIterator(); j.hasNext();) {  
                    Element thirdEle = (Element) j.next();  
                    System.out.println(thirdEle.getName() + ":" + thirdEle.getText());  
                }  
            }  
        } catch (Exception e) {  
            e.printStackTrace();
        }  
    }  
      
    public static void main(String args[]) {  
    	TestDom4jXml.createXml("./xmldoc/dom4j/a.xml");  
        TestDom4jXml.parserXml("./xmldoc/dom/b.xml");  
    }  
}