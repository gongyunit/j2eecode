// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.xml;

import java.io.IOException;
import java.util.ArrayList;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

//将xml中的内容跟对象进行解析和一一映射，并最终存放到list集合中  
public class TestSaxXmlHandler extends DefaultHandler {
    ArrayList<Book> bookList = new ArrayList<Book>();  
    private String currentTag;  
    private Book book;  
    //xml中跟对象book开始位置的映射
    @Override  
    public void startElement(String uri, String localName, String qName,  
            Attributes attributes) throws SAXException {  
        currentTag = qName;  
        if("book".equals(currentTag)) {  
            book = new Book();  
        }  
    }  
  //xml中跟对象中的属性映射
    @Override  
    public void characters(char[] ch, int start, int length)  
            throws SAXException {  
        if("name".equals(currentTag)) {  
            String name = new String(ch,start,length);  
            book.setName(name);  
        }  
        if("author".equals(currentTag)) {  
            String author = new String(ch,start,length);  
            book.setAuthor(author);  
        }  
    }  
  //xml中跟对象映射的结束标志，同时将该对象存放到集合中
    @Override  
    public void endElement(String uri, String localName, String qName)  
            throws SAXException {  
        if("book".equals(qName)) {  
        	bookList.add(book);  
            book = null;  
        }  
        currentTag = null;  
    }  
      
    public ArrayList<Book> getBooks() {  
        return bookList;  
    }  

    @SuppressWarnings("unchecked")  
    public static void main(String[] args) throws ParserConfigurationException,  
            SAXException, IOException {  
        // 创建解析工厂  
        SAXParserFactory factory = SAXParserFactory.newInstance();  
        // 创建解析器  
        SAXParser parser = factory.newSAXParser();  
        // 得到读取器  
        XMLReader reader = parser.getXMLReader();  
        // 设置内容处理器  
        TestSaxXmlHandler handler = new TestSaxXmlHandler();  
        reader.setContentHandler(handler);  
        // 读取xml文档  
        reader.parse("./xmldoc/sax/a.xml");  
        ArrayList list = handler.getBooks();  
        Book book;  
        for(int i = 0; i < list.size(); i++) {  
            book = new Book();  
            book = (Book) list.get(i);  
            System.out.println("书名是："+book.getName() + "；作者是："+book.getAuthor() );  
        }  
  
    }  
}
