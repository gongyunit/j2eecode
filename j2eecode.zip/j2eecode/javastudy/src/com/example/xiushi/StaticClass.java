// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.xiushi;

public class StaticClass {

	//定义静态变量
	public static String name = "hhhh";
	
	//定义静态方法
	public static void printInfo(){
		System.out.println("static method");
	}
	
	public static void main(String[] args) {
		System.out.println(StaticClass.name);//静态变量可以直接调用
		
		StaticClass.printInfo();//静态方法可以直接调用，不用通过new对象的方式
	}
}
