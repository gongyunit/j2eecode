// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.xiushi;

public final class FinalClass {//final修饰类

	//final和static连用修饰变量
	public static final String LABLE="button";
	
	//final修饰方法
	public final void pirntInfo(){
		System.out.println("final method");
	}
	
}
