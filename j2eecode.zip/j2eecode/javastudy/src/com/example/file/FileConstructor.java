// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.file;

import java.io.File;

public class FileConstructor {

	public static void main(String[] args) {
		String fileName = "../../../test/test1.txt";
		File file1 = new File(fileName);
		System.out.println(file1.exists());
	
		String parentRoad = "../../../test/";
		String childRoad = "test1.txt";
		File file2 = new File(parentRoad,childRoad);
		System.out.println(file2.exists());
	}
}
