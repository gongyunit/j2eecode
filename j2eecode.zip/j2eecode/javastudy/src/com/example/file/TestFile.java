// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.file;

import java.io.File;
import java.io.IOException;

public class TestFile {

	public static void main(String[] args) {
		//关于文件的常用方法的测试
		String fileName = "./test/test2.txt";
		File file = new File(fileName);
		//此文件是否存在，返回值是true。
		System.out.println(file.exists());
		//File对象返回的是否是文件，返回值是true
		System.out.println(file.isFile());
		//返回文件的大小
		System.out.println(file.length());
		//获取文件的绝对路径
		System.out.println(file.getAbsolutePath());
		//获取文件的名字
		System.out.println(file.getName());
		
		try {
			//如果文件不存在则创建该文件，但是这里文件已存在，所以返回值是false
			System.out.println(file.createNewFile());
		} catch (IOException e) {
			System.out.println("no problem");
		}
		
//		System.out.println(file.delete());
		
		
		//关于目录的常用方法的测试
		String dirName = "./test2";
		File dirFile = new File(dirName);
		
		//创建目录
		System.out.println(dirFile.mkdirs());
		//获取目录的绝对路径
		System.out.println(dirFile.getAbsolutePath());
		//此目录是否存在，返回值是true
		System.out.println(dirFile.exists());
		//此File对象是否是目录，返回值是true
		System.out.println(dirFile.isDirectory());
		
		//罗列目录下所有子文件和子目录
		File[] files = dirFile.listFiles();
		for(File one : files){
			System.out.println(one.getName());
		}
		
	}
}
