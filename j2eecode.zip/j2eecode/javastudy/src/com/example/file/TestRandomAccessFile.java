// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.file;

import java.io.IOException;
import java.io.RandomAccessFile;

public class TestRandomAccessFile {

	public static void main(String[] args) {
		RandomAccessFile raf = null;
		try {
			raf = new RandomAccessFile("./test/test2.txt","rw");
			
			//通过wirteBytes向文件里边写内容。
			String content = "hello";
			raf.writeBytes(content);
			//向文件中写入内容之后，通过length（）方法获取文件的长度。
			System.out.println(raf.length());
			
			//获取文件的当前指针位置
			System.out.println("filePointer: "+raf.getFilePointer());
			//通过seek（）方法挪动到指定位置，0代表起始位置。目的是为了后续的读取能从开始位置读取。
			raf.seek(0);
			
			//通过read（）方法读取内容
			int fileLength = (int) raf.length();
			byte[] temp = new byte[fileLength];
			raf.read(temp);
			
			//把读取的内容转换成字符串，然后打印出来。
			String tempStr = new String(temp);
			System.out.println(tempStr);
			
		} catch (Exception e) {
		}finally{
			if(raf!=null){
				try {
					//在finally里边，等文件的相关操作结束之后，将文件关闭。此关闭时文件操作一定要进行的方法。
					raf.close();
				} catch (IOException e) {
				}
			}
		}
	}
}
