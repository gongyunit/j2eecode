// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.date;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateFormat {

	//format方法：日期格式化
	public void dtFormat(){
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date=new Date();
		String dateStr=sdf.format(date);
		System.out.println(dateStr);//输出为：当前时间，且格式为：yyyy-MM-dd HH:mm:ss。比如：2015-12-29 15:31:59
	}

	//parse方法用于按照特定格式将表示时间的字符串转换为Date对象
	public void dtParse() throws Exception{
		String str="2014-03-11 13:12";
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Date date=sdf.parse(str);
	 	System.out.println(date);//输出为：Tue Mar 11 13:12:00 CST 2014
	}

	
	public static void main(String[] args) {
		DateFormat df = new DateFormat();
		df.dtFormat();
		try {
			df.dtParse();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
}
