// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.date;

import java.util.Date;

public class DateMethod {

	public static void main(String[] args) {
		long time = 60*60*24*1000;//一天的毫秒数
		
		Date date = new Date();
		date.setTime(time);//通过毫秒数设置时间，以UTC的时间为基准
		System.out.println(date.getTime());//获取偏离UTC时间的毫秒数，输出值是86400000
		
		System.out.println(date.toString());//获取年月日时分秒格式的字符串时间，输出值是Fri Jan 02 08:00:00 CST 1970
		
		Date date2 = new Date();
		date2.setTime(time*2);
		
		System.out.println(date.compareTo(date2));//输出值是-1，说明date比date2靠前
		
	}
}
