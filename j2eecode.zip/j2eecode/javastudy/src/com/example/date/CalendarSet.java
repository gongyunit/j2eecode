// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.date;

import java.util.Calendar;

public class CalendarSet {

	public static void main(String[] args) {
		Calendar c=Calendar.getInstance();
		c.set(Calendar.YEAR, 2015);
		c.set(Calendar.MONTH, 6);
		c.set(Calendar.DATE,3);
		System.out.println(c.getTime());//输出为：Fri Jul 03 16:14:43 CST 2015

		System.out.println(c.get(Calendar.YEAR));//get方法：获取指定字段的值。结果为：2015
	}
}
