// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.date;

import java.util.Calendar;

public class CalendarGetActM {
	public static void main(String[] args) {
		int year=2016;
		Calendar c=Calendar.getInstance();
		c.set(Calendar.YEAR, year);
		c.set(Calendar.MONTH, 1);//设置月份为2月。因为0-11代表1-12月。
		System.out.println(c.getActualMaximum(Calendar.DATE));//输出值是：29。即：2016年2月最多29天

	}
}