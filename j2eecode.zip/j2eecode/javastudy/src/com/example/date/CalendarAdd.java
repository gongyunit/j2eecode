// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.date;

import java.util.Calendar;

public class CalendarAdd {
	public static void main(String[] args) {
		Calendar c=Calendar.getInstance();
		c.add(Calendar.YEAR, 2);	//加2年
		c.add(Calendar.MONTH, -4);	//减4个月
		
		System.out.println(c.getTime());
	}
}
