// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.date;

import java.util.Calendar;
import java.util.Date;

public class CalendarSetGet {

	public static void main(String[] args) {
		Calendar c=Calendar.getInstance();
		Date d = new Date();
		c.setTime(d);//设置date类型的时间
		System.out.println(c.getTime());//获取date类型的时间
	}
}
