// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.date;

import java.util.Calendar;

public class CalendarGetInstance {

	public static void main(String[] args) {
		Calendar c=Calendar.getInstance();
		System.out.println(c.getTime());	//返回Date对象
	}
}
