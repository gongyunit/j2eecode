// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.string;

public class StringClass {

	public void testLength(){
		String str1="hello";
		System.out.println(str1.length());
		String str2="中国";
		System.out.println(str2.length());
	}

	public static void main(String[] args) {
		StringClass sc = new StringClass();
		sc.testLength();
	}
}
