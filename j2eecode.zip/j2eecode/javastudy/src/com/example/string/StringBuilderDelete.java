// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.string;

public class StringBuilderDelete {
	
	public static void main(String[] args) {
		StringBuilder stb = new StringBuilder("hello");
		
		
		System.out.println(stb.delete(4, 4+1));
	}
	
}
