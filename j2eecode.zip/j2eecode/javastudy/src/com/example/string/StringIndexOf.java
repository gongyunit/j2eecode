// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.string;

public class StringIndexOf {

	public static void main(String args[]) {
		String oneStr = new String("chinaokokok");
		String twoSubStr = new String("ok");
		String threeSubStr = new String("ko");

		System.out.print("查找字符 o 第一次出现的位置 :" );
		System.out.println(oneStr.indexOf( 'o' ));
		
		System.out.print("子字符串 twoSubStr 第一次出现的位置:" );
		System.out.println( oneStr.indexOf( twoSubStr ));
		
		System.out.print("从第2个位置开始搜索子字符串 twoSubStr 第一次出现的位置 :" );
		System.out.println( oneStr.indexOf( twoSubStr, 2));
		
		System.out.print("从第7个位置开始搜索子字符串 threeSubStr 最后一次出现的位置 :" );
		System.out.println(oneStr.lastIndexOf( threeSubStr,7));
	}
}
