// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.string;

public class StringSubstring {

	public static void main(String[] args) {
		String oneStr = "starbegining";
		
		System.out.println(oneStr.substring(1));
		System.out.println(oneStr.substring(1,5));
	}
}
