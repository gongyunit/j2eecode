// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.string;

public class StringValueOf {

	public static void main(String[] args) {
		double a = 22.33;
		
		boolean b = false;
		
		long c = 22l;
		
		char[] tt = {'a','b'};
		
		System.out.println(String.valueOf(a));
		System.out.println(String.valueOf(b));
		System.out.println(String.valueOf(c));
		System.out.println(String.valueOf(tt));
	}
}
