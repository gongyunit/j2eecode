// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.string;

public class StringToCase {

	public static void main(String[] args) {
		String name = "世界Hello";
		
		System.out.println(name.toUpperCase());
		System.out.println(name.toLowerCase());
	}
}
