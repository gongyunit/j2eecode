// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.socket;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;


public class TestTCPClient {

	public static void main(String[] args) {
		try {
			Socket client = new Socket("127.0.0.1" , 3333);
	        InputStream in = client.getInputStream();
	        OutputStream out = client.getOutputStream();
	        
	        String content  = "hello,world!";
	        out.write(content.getBytes());
	        
	        byte[] receiveInfo = new byte[30];
       		in.read(receiveInfo);
	        System.out.println("客户端收到:" + new String(receiveInfo));
	        
	        out.close();
	        in.close();
	        client.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
