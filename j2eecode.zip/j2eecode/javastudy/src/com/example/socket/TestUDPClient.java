// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.socket;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class TestUDPClient {
    public static void main(String[] args){
		try {
			DatagramSocket client = new DatagramSocket();
			
	        String sendStr = "UDPClient send content";
	        byte[] sendBuf;
	        sendBuf = sendStr.getBytes();
	        InetAddress addr = InetAddress.getByName("127.0.0.1");
	        int port = 6666;
	        DatagramPacket sendPacket = new DatagramPacket(sendBuf ,sendBuf.length , addr , port);
	        client.send(sendPacket);
	        
	        byte[] recvBuf = new byte[30];
	        DatagramPacket recvPacket = new DatagramPacket(recvBuf , recvBuf.length);
	        client.receive(recvPacket);
	        String recvStr = new String(recvPacket.getData() , 0 ,recvPacket.getLength());
	        System.out.println("客户端收到: " + recvStr);
	        
	        client.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
}
