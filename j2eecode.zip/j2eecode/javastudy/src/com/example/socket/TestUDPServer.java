// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.socket;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class TestUDPServer {
    public static void main(String[] args){
		try {
			DatagramSocket server = new DatagramSocket(6666);
			
	        byte[] recvBuf = new byte[30];
	        DatagramPacket recvPacket = new DatagramPacket(recvBuf , recvBuf.length);
	        server.receive(recvPacket);
	        String recvStr = new String(recvPacket.getData() , 0 , recvPacket.getLength());
	        System.out.println("服务端收到： " + recvStr);
	        
	        int port = recvPacket.getPort();
	        InetAddress addr = recvPacket.getAddress();
	        String sendStr = "UDPsever send content";
	        byte[] sendBuf;
	        sendBuf = sendStr.getBytes();
	        DatagramPacket sendPacket = new DatagramPacket(sendBuf , sendBuf.length , addr , port );
	        server.send(sendPacket);
	        
	        server.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
}
