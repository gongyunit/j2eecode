// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.socket;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class TestTcpServer {

	public static void main(String[] args) {
		   
		try {
			ServerSocket listen = new ServerSocket(3333);
	        Socket server  = listen.accept();
	        InputStream in = server.getInputStream();
	        OutputStream out = server.getOutputStream();
	        
	        byte[] content = new byte[30];
       		in.read(content);
	        System.out.println("服务端收到:" + new String(content));

	        String sendInfo  = "No Problem!";
	        out.write(sendInfo.getBytes());
	        
	        out.close();
	        in.close();
	        server.close();
	        listen.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	        

	}
}
