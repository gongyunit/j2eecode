// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.mianobject;

public class Test {

	public static boolean isSonClass(Person ps){
		if(ps instanceof Women){
			return true;
		}else{
			return false;
		}
		
		
	}
	
	public static void main(String[] args) {
		Person ps = new Women();
		if(isSonClass(ps)){
			ps.runQuick();
			System.out.println("多态运用成功");
		}
		
	}
}
