// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.mianobject;

public class MianOverload {

	public void add(int a){
		
		System.out.println("a: "+a);
	}
	
	
	public String add(String name){//参数类型不同的重载,同时更改了返回值类型
		System.out.println("name: "+name);
		
		return name;
	}
	
	
	public void add(String name,int a){//参数个数不同的重载
		System.out.println("name: "+name+" a : "+a);
	}
	
	public void add(int a,String name){//参数顺序不同的重载
		System.out.println("a: "+a+" name : "+name);
		
	}
	
	public static void main(String[] args) {
		MianOverload mo = new MianOverload();
		mo.add(1);
		mo.add("add");
		mo.add(1, "add");
		mo.add("addmo", 5);
	}
	
	
}
