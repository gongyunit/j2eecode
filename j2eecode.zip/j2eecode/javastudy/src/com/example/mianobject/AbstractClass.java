// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.mianobject;

public abstract class AbstractClass {

	String name;
	int number;
	
	public void printInfo(){
		System.out.println("hello");
	}
	
	public abstract void cout();//抽象方法
	
}
