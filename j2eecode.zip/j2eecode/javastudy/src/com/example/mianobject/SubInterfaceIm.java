// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.mianobject;

public class SubInterfaceIm implements CommonInterface {

	@Override
	public void add() {
		int a = 1; 
		int b = 3;
		
		System.out.println(a+b);

	}

	@Override
	public void move() {
		System.out.println("animal move");
	}
	
	public static void main(String[] args) {
		SubInterfaceIm si = new SubInterfaceIm();
		si.add();
		si.move();
	}

}
