// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.mianobject;

public class Animal {
	
	private String name;
	private int age;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}

	public static void main(String[] args) {
		//以下是通过调用封装的方法，来访问设置权限的变量
		Animal animal = new Animal();
		
		animal.setName("xiaoniao");
		animal.setAge(4);
		
		System.out.println(animal.getName());
		System.out.println(animal.getAge());
	}
		
}
