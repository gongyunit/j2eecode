// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.mianobject;

public class Man extends Person {
	
	public void runQuick(){
		System.out.println("Man is ruuning");
	}
	
	public static void main(String[] args) {
		Person p = new Person();
		Person m = new Man();
		
		p.runQuick();//执行的是父类Person中的方法
		
		m.runQuick();//虽然是父类Person的引用，但是执行的是Man的方法
	}
}
