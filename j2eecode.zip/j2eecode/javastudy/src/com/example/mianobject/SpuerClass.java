// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.mianobject;

public class SpuerClass {

	public int number ;
	
	SpuerClass(){
		System.out.println("SpuerClass()");
	}
	
	SpuerClass(int number) {
		System.out.println("SpuerClass(int number)");
		this.number = number;
   }
	
}
