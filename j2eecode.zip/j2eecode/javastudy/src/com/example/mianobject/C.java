// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.mianobject;

public class C implements A, B {

	@Override
	public void add() {
		// TODO Auto-generated method stub

	}

	@Override
	public void printInfo() {
		// TODO Auto-generated method stub

	}

}
