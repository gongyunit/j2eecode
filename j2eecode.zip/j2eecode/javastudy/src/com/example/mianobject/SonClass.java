// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.mianobject;

public class SonClass extends AbstractClass {

	@Override
	public void cout() {//实现了父类中的抽象方法
		System.out.println(56);
	}

	public static void main(String[] args) {
		SonClass sc = new SonClass();//子类才能实例化，而抽象类AbstractClass不能实例化
		sc.printInfo();//继承的子类可以调用抽象父类的方法
		sc.cout();
	}
}
