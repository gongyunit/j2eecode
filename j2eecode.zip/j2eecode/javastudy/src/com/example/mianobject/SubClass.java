// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.mianobject;

public class SubClass extends SpuerClass{

	public int number;
	
	SubClass(){
		super(100);//虽然子类中显示的调用父类构造函数，但是并没有将其继承过来，查看此类最后的输出便知晓
		System.out.println("SubClass()");
	}
	
	SubClass(int number) {
		System.out.println("SubClass(int number) "+ number);
		this.number = number;
   }
	
	public void printInfo(){
		System.out.println(super.number);
		System.out.println(this.number);
	}
	
	public static void main(String[] args) {
		SubClass subclass = new SubClass(300);
//		subclass.printInfo();
	}
}
