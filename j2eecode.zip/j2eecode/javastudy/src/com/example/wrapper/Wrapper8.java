// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.wrapper;

public class Wrapper8 {

	public static void main(String[] args) {
		Integer intone = 5;
		Long longone = 3l;
		Double doubleone = 7.8;
		Short shortone = 36;
		Float floatone = 2.3f;
		Byte byteone = 2;
		Character charone = 'a';
		Boolean booleanone = true;

		System.out.println(intone.intValue());
		System.out.println(longone.longValue());
		System.out.println(doubleone.doubleValue());
		System.out.println(shortone.shortValue());
		System.out.println(floatone.floatValue());
		System.out.println(byteone.byteValue());
		System.out.println(charone.charValue());
		System.out.println(booleanone.booleanValue());
	}
}
