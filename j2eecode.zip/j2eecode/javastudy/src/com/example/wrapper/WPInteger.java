// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.wrapper;

public class WPInteger {

	public static void main(String[] args) {
//		Integer i = 11;//自动装箱，实际上执行了Integer i = Integer.valueOf(11);
//		int t = i;//自动拆箱，实际上执行了 int t = i.intValue();
						
		String intStr = "216";
		int one = Integer.parseInt(intStr);//此方法是静态方法可以用包装类直接调用
		
		System.out.println(one);//输出为int型值：216
		
		

	}
}
