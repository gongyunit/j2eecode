// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.doc;

/**
 * The<code>DocClass</code>class represents about doc's content…
 * … …
 * @author john
 * @version 1.3
 * @see  java.lang.String
 * @since JDK6.0
 */

public class DocClass {

	/**
	  *  the method printInfo represents print some important info
	  * @param info The value to be squared
	  * @return no return
	  * @throws no exception
	  */

	public void printInfo(String info){
		
	}
}
