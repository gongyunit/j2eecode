// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.innerclass;

public class Outer3 { 
    public Inner getInner(final String name) { 
        return new Inner() { 
            private String nameStr = name; 
 
            public String getName() { 
                return nameStr; 
            } 
        }; 
    } 
    
    public static void main(String[] args) { 
    	Outer3 outer = new Outer3(); 
        Inner inner = outer.getInner("Inner"); 
        System.out.println(inner.getName()); 
    } 
} 


 
//匿名内部类的接口
interface Inner { 
    String getName(); 
} 
