// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.innerclass;

public class Outer2 {
	 private String sex;
	    public static String name = "bbbb";
	    
	  //静态内部类定义
	    static class InnerClass1{
	        // 在静态内部类中可以存在静态成员
	        public static String name2 = "cccccc";
	        
	        public void display(){
	            //静态内部类只能访问外围类的静态成员变量和方法，不能访问外围类的非静态成员变量和方法
	            System.out.println("Outer2 name :" + name);
	        }
	    }

	    public void display(){
	       //外围类访问静态内部类：内部类.
	        System.out.println(InnerClass1.name2);
	        // 静态内部类 可以直接创建实例不需要依赖于外围类 
	        new InnerClass1().display();
	        
	    }
	    
	    public static void main(String[] args) {
	    	Outer2 outer2 = new Outer2();
	        outer2.display();
	    }
}
