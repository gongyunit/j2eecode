// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.innerclass;

public class Parcel4 {

    public void destionation(String str){
    	//定义在方法内的内部类
        class PDestionation {
            private String label;
            private PDestionation(String whereTo){
                label = whereTo;
            }
            
            public void readLabel(){
               System.out.println(this.label);
            }
        }
        PDestionation pd = new PDestionation(str);
        pd.readLabel();
        
    }
    
    public static void main(String[] args) { 
        Parcel4 p = new Parcel4(); 
        p.destionation("aaaaa"); 
    } 
}
