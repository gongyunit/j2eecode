// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.innerclass;

public class Outer1 {
 
    //成员内部类的定义
    public class Inner { 
        public void print(String str) { 
            System.out.println(str); 
        } 
    } 
	   
	public Inner getInner() { 
	 return new Inner(); 
	} 
    
    public static void main(String[] args) { 
    	Outer1 outer1 = new Outer1(); 
    	Outer1.Inner inner = outer1.new Inner(); 
        inner.print("Outer1.new"); 
 
        inner = outer1.getInner(); 
        inner.print("Outer1.get"); 
    } 
	
}
