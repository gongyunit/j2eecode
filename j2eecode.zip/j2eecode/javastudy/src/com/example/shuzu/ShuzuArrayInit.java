// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.shuzu;

public class ShuzuArrayInit {
	public static void main(String[] args) {
		
		int[] aa = {1,2,3};
		
		int[] bb ;
		
		bb = new int[]{1,2,3};
		
	}
}
