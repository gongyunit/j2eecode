// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.shuzu;

import java.util.Arrays; //通过import引入Arrays对象

public class ShuzuSort {

	public static void main(String[] args) {
		int[] aa = {1,5,3,2};
		
		Arrays.sort(aa); //这里需要用Arrays，是通过import引入的，所以ShuzuSort类中引用时，就不需要再写包名了。
		
		for(int temp:aa){
			System.out.println(temp);
		}
		//输出结构为：1，2，3，5
		
		int[] bb = {8,5,3,2};
		Arrays.sort(bb, 1, 4);
		for(int temp:bb){
			System.out.println(temp);
		}
		
		//输出结构为：8，2，3，5
	}
}