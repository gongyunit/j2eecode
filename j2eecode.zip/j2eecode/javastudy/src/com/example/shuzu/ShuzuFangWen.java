// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.example.shuzu;

public class ShuzuFangWen {

	public static void main(String[] args) {
		int[] aa = new int[3];
		
		aa = new int[]{1,2,3};
		
		System.out.println(aa.length);//访问数组长度，值为3
		System.out.println(aa[2]);//访问数组元素，下标最大值为2，输出值为3
		
		//遍历数组元素，循环打印出的值为：1，2，3
		for(int temp:aa){
			System.out.println(temp);
		}
	}
}
