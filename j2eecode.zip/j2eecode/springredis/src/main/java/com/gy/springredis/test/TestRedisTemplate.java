// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.springredis.test;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.SetOperations;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.data.redis.core.ZSetOperations;

public class TestRedisTemplate {
	public static void main(String[] args) {
        ClassPathXmlApplicationContext appCtx = new ClassPathXmlApplicationContext("config/spring-redis.xml");
        final RedisTemplate<String, Object> redisTemplate = appCtx.getBean("redisTemplate",RedisTemplate.class);
        
        //添加一个 key 
        ValueOperations<String, Object> value = redisTemplate.opsForValue();
        value.set("tkey", "hello key");
        //获取 这个 key 的值
        System.out.println(value.get("tkey"));
        
        
        //添加 一个 hash集合
        HashOperations<String, Object, Object>  hash = redisTemplate.opsForHash();
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("name", "thashmap");
        map.put("age", "99");
        hash.putAll("thashmap", map);
        //获取 map
        System.out.println(hash.entries("thashmap"));
        
        
        //添加 一个 list 列表
        ListOperations<String, Object> list = redisTemplate.opsForList();
        list.rightPush("tlist", "list1");
        list.rightPush("tlist", "list2");
        //输出 list
        System.out.println(list.range("tlist", 0, 1));
        
        
        //添加 一个 set 集合
        SetOperations<String, Object> set = redisTemplate.opsForSet();
        set.add("tset", "set1");
        set.add("tset", "set2");
        set.add("tset", "set3");
        //输出 set 集合
        System.out.println(set.members("tset"));
        
        
        //添加有序的 set 集合
        ZSetOperations<String, Object> zset = redisTemplate.opsForZSet();
        zset.add("tzset", "zset1", 0);
        zset.add("tzset", "zset2", 1);
        zset.add("tzset", "zset3", 2);
        //输出有序 set 集合
        System.out.println(zset.rangeByScore("tzset", 0, 2));
    }
}
