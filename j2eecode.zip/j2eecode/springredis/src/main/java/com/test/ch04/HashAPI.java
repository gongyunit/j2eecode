// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.ch04;

import redis.clients.jedis.Jedis;

public class HashAPI {
	private static Jedis redis;

	static {
		redis = new Jedis("127.0.0.1", 6379);
	}
	
	public static void main(String[] args) {
		System.out.println("================hash=================");
		System.out.println("清空数据："+redis.flushDB());
		System.out.println("==================增加================");
		System.out.println("hashs添加key001=>value001"+redis.hset("hashs", "key001", "value001"));
		System.out.println("hashs添加key002=>value002"+redis.hset("hashs", "key002", "value002"));
		System.out.println("hashs添加key003=>value003"+redis.hset("hashs", "key003", "value003"));
		System.out.println("hashs添加key004=>4L"+redis.hincrBy("hashs", "key004", 4L));
		System.out.println("hashs:"+redis.hgetAll("hashs"));
		System.out.println("===================查询================");
		System.out.println("判断是否存在key001："+redis.hexists("hashs", "key001"));
		System.out.println("查找key001的值："+redis.hget("hashs", "key001"));
		System.out.println("获得所有集合的key："+redis.hkeys("hashs"));
		System.out.println("获得所有集合的value："+redis.hvals("hashs"));

		System.out.println("=============修改====================");
        System.out.println("修改key001值为value001_update:"+redis.hset("hashs", "key001", "value001_update"));
        System.out.println("修改key004值增加11:"+redis.hincrBy("hashs", "key004", 11L));
        System.out.println("hashs:"+redis.hvals("hashs"));

        System.out.println("=============删除=======================");
        System.out.println("删除key002："+redis.hdel("hashs", "key002"));
        System.out.println("hashs:"+redis.hgetAll("hashs"));
        
        redis.close();

	}

}
