// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.ch04;

import redis.clients.jedis.Jedis;

public class SortedSetAPI {

	private static Jedis redis;
	
	static {
		redis = new Jedis("127.0.0.1", 6379);
	}
	
	public static void main(String[] args) {
        //有序集合类似
		System.out.println("=================SortedSet================");
		System.out.println("清空数据："+redis.flushDB());
		System.out.println("==============增加===============");
		System.out.println("名为zsets添加数据value1："+redis.zadd("zsets",1, "value1"));
		System.out.println("名为zsets添加数据value2："+redis.zadd("zsets",2, "value2"));
		System.out.println("名为zsets添加数据value3："+redis.zadd("zsets",3, "value3"));
		System.out.println("名为zsets添加数据value4："+redis.zadd("zsets",4, "value4"));
		System.out.println("名为zsets添加数据value4："+redis.zadd("zsets",4, "value4"));
		System.out.println("zsets："+redis.zrange("zsets", 0, -1));

		System.out.println("===============查询===============");
		System.out.println("查找元素的个数："+redis.zcard("zsets"));
		System.out.println("查找权重范围内元素的个数："+redis.zcount("zsets",1,3));
		System.out.println("查找元素value4的权重："+redis.zscore("zsets","value4"));

		System.out.println("=============修改===================");

		System.out.println("=============删除===================");
		System.out.println("删除value4:"+redis.zrem("zsets", "value4"));
		System.out.println("redis:"+redis.zrange("zsets", 0, -1));

        redis.close();
	}

}
