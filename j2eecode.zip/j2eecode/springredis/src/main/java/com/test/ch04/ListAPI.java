// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.ch04;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.SortingParams;

public class ListAPI {

	private static Jedis redis;

	static {
		redis = new Jedis("127.0.0.1", 6379);
	}
	
	public static void main(String[] args) {
		//list存储结构是栈类型的 最后插入的索引是0
		System.out.println("====================list======================");
		System.out.println("清空数据："+redis.flushDB());
		System.out.println("===========增加=================");
		System.out.println("添加了字符串list");
		System.out.println("listString:"+redis.lpush("listString", "vector"));
		System.out.println("listString:"+redis.lpush("listString", "vector"));
		System.out.println("listString:"+redis.lpush("listString", "arraylist"));
		System.out.println("listString:"+redis.lpush("listString", "hashmap"));
		System.out.println("listNumber:"+redis.lpush("listNumber", "1"));
		System.out.println("listNumber:"+redis.lpush("listNumber", "4"));
		System.out.println("listNumber:"+redis.lpush("listNumber", "3"));
		System.out.println("listNumber:"+redis.lpush("listNumber", "2"));
		System.out.println("listString全部元素："+redis.lrange("listString", 0, -1));
		System.out.println("listNumber全部元素："+redis.lrange("listNumber", 0, -1));
		System.out.println("");
		System.out.println("============修改=================");
		System.out.println("对指定下标进行修改："+redis.lset("listString", -1, "vector-update"));
		System.out.println("修改后的0下标值："+redis.lindex("listString", 0));
		System.out.println("删除后的元素："+redis.lrange("listString", 0, -1));
		System.out.println("");
		System.out.println("==============删除================");
		System.out.println("删除指定的元素，重复的删除后添加的："+redis.lrem("listString", 1, "vector"));
		System.out.println("删除后的元素："+redis.lrange("listString", 0, -1));
		System.out.println("");
         /*
         * list中存字符串时必须指定参数为alpha，如果不使用SortingParams，而是直接使用sort("list")，
         * 会出现"ERR One or more scores can't be converted into double"
         */
        SortingParams sortingParameters = new SortingParams();
        sortingParameters.alpha();//目测是根据字母顺序排序
        System.out.println("排序元素："+redis.sort("listString",sortingParameters));
        System.out.println("排序元素："+redis.sort("listNumber"));
        
        redis.close();
	}

}
