// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.ch04;

import redis.clients.jedis.Jedis;

public class StringAPI {
	
	private static Jedis redis;

	static {
		redis = new Jedis("127.0.0.1", 6379);
	}

	public static void main(String[] args) {
		System.out.println("=====================string========================");
		System.out.println("清空数据："+redis.flushDB());
		System.out.println("============单个增删改=============");
		System.out.println("增加key001:"+redis.set("key001", "key001value"));
		System.out.println("修改key001："+redis.set("key001", "key-update")+" "+redis.get("key001"));
		System.out.println("最后追加字符串："+redis.append("key001", "-append")+" "+redis.get("key001"));
		System.out.println("删除key001："+redis.del("key001"));

		System.out.println("==================多个一起添加,删除==================");
		System.out.println("增减key021，key022，key023："+redis.mset("key021","key021value","key022","key022value","key023","key023value"));
		System.out.println("一次获取多个key值："+redis.mget("key021","key022","key023"));
		System.out.println("一次删除多个key："+redis.del(new String[]{"key021","key022"}));
		System.out.println("获取key021："+redis.get("key021"));

		System.out.println("===========other=======================");
		System.out.println("不在在key时再添加值："+redis.setnx("key031", "key031value"));
		System.out.println("不在在key时再添加值："+redis.setnx("key032", "key032value"));
		System.out.println("存在在key时再添加值："+redis.setnx("key032", "key032value_tow"));
		System.out.println("key031:"+redis.get("key031"));
		System.out.println("key032值没变:"+redis.get("key032"));

		System.out.println("添加key033并设置过期时间："+redis.setex("key033", 2, "key033value"));
        try {
            Thread.sleep(3000L);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println("获取key033值："+redis.get("key033"));
        System.out.println("获取值得子串key032:"+redis.getrange("key032",1, 5));

        redis.close();
	}

}
