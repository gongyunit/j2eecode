// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.ch04;

import redis.clients.jedis.Jedis;

public class KeyAPI {

	private static Jedis redis;

	static {
		redis = new Jedis("127.0.0.1", 6379);
	}

	public static void main(String[] args) {
		System.out.println("==============key=========================");
		// 清空数据
		System.out.println("清空库中所有数据：" + redis.flushDB());
		;
		System.out.println("判断key111是否存在" + redis.exists("key111"));
		System.out.println("增加key111:" + redis.set("key111", "hello world"));
		System.out.println("输出key111:" + redis.get("key111"));
		System.out.println("增加新的key112：" + redis.set("key112", "key112value"));
		System.out.println("增加新的key113：" + redis.set("key113", "key113value"));
		// 输出所有key的的值 无序的
		for (String key : redis.keys("*")) {
			System.out.println(key + ":" + redis.get(key));
		}
		System.out.println("删除key111：" + redis.del("key111"));
		System.out.println("key111是否存在：" + redis.exists("key111"));
		// 设置key的过期时间
		System.out.println("设置key112的过期时间3秒" + redis.expire("key112", 3));
		try {
			Thread.sleep(2000L);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("key112的剩余生存时间：" + redis.ttl("key112"));
		System.out.println("key112的取消过期时间：" + redis.persist("key112"));
		System.out.println("查看key112是否还存在：" + redis.exists("key112"));
		System.out.println("查看key112的value类型：" + redis.type("key112"));
		System.out.println("给key113改成key114：" + redis.rename("key113", "key114"));
		System.out.println("查看key114value：" + redis.get("key114"));

		redis.close();
	}
}
