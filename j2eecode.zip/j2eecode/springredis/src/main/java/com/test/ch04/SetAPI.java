// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.ch04;

import redis.clients.jedis.Jedis;

public class SetAPI {
	private static Jedis redis;

	static {
		redis = new Jedis("127.0.0.1", 6379);
	}
	
	public static void main(String[] args) {
		System.out.println("=====================set=====================");
		System.out.println("清空数据："+redis.flushDB());
		System.out.println("============增加==============");
		System.out.println("名为sets的集合中添加元素value1"+redis.sadd("sets", "value1"));
		System.out.println("名为sets的集合中添加元素value2"+redis.sadd("sets", "value2"));
		System.out.println("名为sets的集合中添加元素value3"+redis.sadd("sets", "value3"));
		System.out.println("sets所有值："+redis.smembers("sets"));
		System.out.println("===============修改=============");
		System.out.println("无法修改指定的值但是,不能存入相同的值："+redis.sadd("sets", "value2"));
		System.out.println("sets:"+redis.smembers("sets"));
		System.out.println("============查询==================");
        for(String value : redis.smembers("sets")){
        	System.out.println(value);
        }
        System.out.println("判断元素是否在集合中："+redis.sismember("sets", "value2"));
        System.out.println("==============删除=============");
        System.out.println("删除指定的值："+redis.srem("sets", "value2"));
        System.out.println("元素出栈："+redis.spop("sets"));
        System.out.println("sets:"+redis.smembers("sets"));
        System.out.println("");
        System.out.println("==============集合运算=================");
        System.out.println("名为sets1的集合中添加元素value1"+redis.sadd("sets1", "value1"));
        System.out.println("名为sets1的集合中添加元素value2"+redis.sadd("sets1", "value2"));
        System.out.println("名为sets1的集合中添加元素value3"+redis.sadd("sets1", "value3"));
        System.out.println("名为sets2的集合中添加元素value3"+redis.sadd("sets2", "value3"));
        System.out.println("名为sets2的集合中添加元素value4"+redis.sadd("sets2", "value4"));
        System.out.println("名为sets2的集合中添加元素value5"+redis.sadd("sets2", "value5"));
        System.out.println("sets1所有值："+redis.smembers("sets1"));
        System.out.println("sets2所有值："+redis.smembers("sets2"));
        System.out.println("sets1和sets2的交集："+redis.sinter("sets1","sets2"));
        System.out.println("sets1和sets2的并集："+redis.sunion("sets1","sets2"));
        System.out.println("sets1和sets2的差集："+redis.sdiff("sets1","sets2"));
        
        redis.close();

	}

}
