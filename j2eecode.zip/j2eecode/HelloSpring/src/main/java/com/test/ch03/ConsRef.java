// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.ch03;

public class ConsRef {
	ITestCons testCons;

	public void finalSayCons() {
		testCons.sysCons();
	}

	public ConsRef(ITestCons testCons) {
		this.testCons = testCons;
	}
}
