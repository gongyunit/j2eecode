// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.ch07;

import java.lang.reflect.Method;

import org.springframework.aop.MethodBeforeAdvice;

public class TestAOPBeforeMethod implements MethodBeforeAdvice {

	public void before(Method arg0, Object[] arg1, Object arg2) throws Throwable {
        System.out.println("TestAOPBeforeMethod : Before method TestAOPBeforeMethod!");
	}
}
