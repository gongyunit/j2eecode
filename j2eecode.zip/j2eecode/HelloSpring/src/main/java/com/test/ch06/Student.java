// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.ch06;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class Student {

	    private String name;  
	    private String [] courseName;//数组  
	    private List<Course> courseList;//list集合  
	    private Set<Course> courseSets;//set集合  
	    private Map<String,Course> courseMaps;//map集合  
	    private Properties pp;//Properties的使用  
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String[] getCourseName() {
			return courseName;
		}
		public void setCourseName(String[] courseName) {
			this.courseName = courseName;
		}
		public List<Course> getCourseList() {
			return courseList;
		}
		public void setCourseList(List<Course> courseList) {
			this.courseList = courseList;
		}
		public Set<Course> getCourseSets() {
			return courseSets;
		}
		public void setCourseSets(Set<Course> courseSets) {
			this.courseSets = courseSets;
		}
		public Map<String, Course> getCourseMaps() {
			return courseMaps;
		}
		public void setCourseMaps(Map<String, Course> courseMaps) {
			this.courseMaps = courseMaps;
		}
		public Properties getPp() {
			return pp;
		}
		public void setPp(Properties pp) {
			this.pp = pp;
		}
	    
	    
}
