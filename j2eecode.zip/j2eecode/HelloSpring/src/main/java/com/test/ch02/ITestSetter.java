// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.ch02;

public interface ITestSetter {
	void saySetter();
}
