// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.ch07;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

public class TestAOPMethodInterceptor implements MethodInterceptor {

	public Object invoke(MethodInvocation arg0) throws Throwable {
		//打印要执行的方法的名字
		System.out.println("Method name : "+ arg0.getMethod().getName());
		// 在方法调用前要执行的事情，功能类似于MethodBeforeAdvice
		System.out.println("TestAOPMethodInterceptor : Before method invoke!");

		try {
			// 执行调用的方法
			Object result = arg0.proceed();

			// 在方法调后前要执行的事情，功能类似于AfterReturningAdvice
			System.out.println("TestAOPMethodInterceptor : after method invoke!");
			return result;

		} catch (ClassCastException e) {
			// 如果调用的方法出现异常，则执行以下操作，功能类似于ThrowsAdvice
			System.out.println("TestAOPMethodInterceptor : Throw exception invoke!");
			throw e;
		}
	}

}
