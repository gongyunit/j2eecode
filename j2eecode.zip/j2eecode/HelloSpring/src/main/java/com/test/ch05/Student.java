// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.ch05;

public class Student {

	private Course course;
	
	public Student(Course course) {
		super();
		this.course = course;
	}

	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}
	
	public void printStudent(){
		System.out.println("I am a Student");
		course.printCource();
	}
}
