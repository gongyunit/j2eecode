// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.ch03;

public interface ITestCons {
	void sysCons();
}
