// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.ch03.impl;

import com.test.ch03.ITestCons;

public class TestCons implements ITestCons {

	public void sysCons() {
		System.out.println("This is Cons");
	}

}
