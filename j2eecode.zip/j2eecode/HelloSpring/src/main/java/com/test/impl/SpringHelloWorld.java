// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.impl;

import com.test.HelloWorld;

public class SpringHelloWorld implements HelloWorld {

	public void sayHello() {
		System.out.println("Spring Say Hello!!");
	}

}
