// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.ch07;

public class StudentService {

	private String name;
	
	private String favorite;

	public void setName(String name) {
		this.name = name;
	}

	public void setFavorite(String favorite) {
		this.favorite = favorite;
	}
	
	public void printName() {
		System.out.println("Student name : " + this.name);
	}

	public void printFavorite() {
		System.out.println("Student favorite : " + this.favorite);
	}

	public void goThrowException() {
		throw new ClassCastException();
	}
	
}
