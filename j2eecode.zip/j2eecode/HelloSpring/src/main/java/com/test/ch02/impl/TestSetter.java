// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.ch02.impl;

import com.test.ch02.ITestSetter;

public class TestSetter  implements ITestSetter {

	public void saySetter() {
		System.out.println("This is saySetter");
	}

}
