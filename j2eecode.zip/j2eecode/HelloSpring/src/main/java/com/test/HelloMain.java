// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class HelloMain {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"beans.xml");

		HelloWorldService service = (HelloWorldService) context
				.getBean("helloWorldService");

		HelloWorld hw = service.getHelloWorld();

		hw.sayHello();

	}

}
