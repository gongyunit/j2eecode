// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.ch07;

import org.springframework.aop.ThrowsAdvice;

public class TestAOPThrowException implements ThrowsAdvice {
	public void afterThrowing(ClassCastException e) throws Throwable {
		System.out.println("TestAOPThrowException : Throw exception TestAOPThrowException!");
	}
}
