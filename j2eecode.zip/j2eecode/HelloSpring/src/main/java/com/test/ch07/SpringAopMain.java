// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.ch07;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringAopMain {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"beansaop.xml");
		StudentService studentService=(StudentService) context.getBean("studentServiceProxy4");  
		System.out.println("*************************");
		studentService.printName();
		System.out.println("*************************");
		studentService.printFavorite();
		System.out.println("*************************");
		try {
			studentService.goThrowException();
		} catch (Exception e) {

		}
	}

}
