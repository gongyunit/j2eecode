// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.ch02;

public class SetterRef {
	ITestSetter testSetter;

	public void finalSaySetter() {
		testSetter.saySetter();
	}

	public void setTestSetter(ITestSetter testSetter) {
		this.testSetter = testSetter;
	}
 
}
