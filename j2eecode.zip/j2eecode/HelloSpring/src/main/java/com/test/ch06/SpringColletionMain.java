// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.ch06;

import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Map.Entry;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.test.ch06.Course;
import com.test.ch06.Student;


public class SpringColletionMain {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"beanscol.xml");
		Student student=(Student) context.getBean("student");  
        System.out.println(student.getName());  
        
        //通过数组获取数据
        System.out.println("**********通过数组获取数据*****");  
        for(String courseName:student.getCourseName()){  
            System.out.println(courseName);  
        }  
        /* 
         * 通过list集合取出数据 
         */  
        System.out.println("**********通过list集合取出数据*****");  
        for(Course course : student.getCourseList()){  
            System.out.println("name="+course.getName());  
        }  
        /* 
         * 通过set集合取出数据 
         */  
        System.out.println("**********通过set集合取出数据*****");  
        for(Course course : student.getCourseSets()){  
              
            System.out.println("name="+course.getName());  
        }  
        /* 
         * 通过map集合取出数据 迭代器 
         */  
        System.out.println("*******通过map集合取出数据****");  
          
        //1.迭代器  
        Map<String,Course> courseMaps=student.getCourseMaps();  
        Iterator it=courseMaps.keySet().iterator();  
        while(it.hasNext()){  
            String key=(String) it.next();  
            Course course=courseMaps.get(key);  
            System.out.println("key="+key+" "+course.getName());  
        }  
          
        System.out.println("*****通过Propertis取出数据*****");  
        Properties pp=student.getPp();  
        for(Entry<Object,Object> entry:pp.entrySet()){  
            System.out.println(entry.getKey().toString()+" "+entry.getValue().toString());  
        }  
	}

}
