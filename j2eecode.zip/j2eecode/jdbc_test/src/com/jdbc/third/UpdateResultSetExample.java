// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.jdbc.third;

//第一步：导入包
import java.sql.*;

public class UpdateResultSetExample {
	// JDBC 驱动和访问url
		static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
		static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/template";

		// 数据库用户名和密码
		static final String USER = "root";
		static final String PASS = "123456";

		public static void main(String[] args) {
			Connection conn = null;
			Statement stmt = null;
			try {
				// 第二步：注册驱动
				Class.forName("com.mysql.jdbc.Driver");

				// 第三步：打开连接
				System.out.println("Connecting to database...");
				conn = DriverManager.getConnection(DB_URL, USER, PASS);

				// 第四步：执行查询。通过Statement接口调用
				System.out.println("Creating statement...");
				System.out.println("Creating statement...");
				stmt = conn.createStatement(
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_UPDATABLE);
				
				String sql;
				sql = "select personid, name from person";
				ResultSet rs = stmt.executeQuery(sql);

				//打印出当前的结果
				printRs(rs);
				rs.beforeFirst();
				
				// 第五步：循环更新结果集的每一行，将每一行的名字列加5
				while (rs.next()) {
					String newName = rs.getString("name") + 5;
					rs.updateString("name", newName);
					rs.updateRow();
				}
				//打印出更新后的结果
				printRs(rs);

				// 第六步：关闭结果集
				rs.close();
				stmt.close();
				conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				// 第七步：finally 中关闭资源，包括：Statement和连接
				try {
					if (conn != null)
						conn.close();
				} catch (SQLException se) {
					se.printStackTrace();
				}
			}
			System.out.println("end!");
		}
	
		public static void printRs(ResultSet rs) throws SQLException {
			rs.beforeFirst();
			while (rs.next()) {
				int id = rs.getInt("personid");
				String name = rs.getString("name");
	
				System.out.print("ID: " + id);
				System.out.print(", Name: " + name);
			}
			System.out.println();
		}
	}
	
