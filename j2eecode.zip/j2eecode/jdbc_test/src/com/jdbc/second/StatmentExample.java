// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.jdbc.second;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class StatmentExample {

	// JDBC 驱动和访问url
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/template";

	// 数据库用户名和密码
	static final String USER = "root";
	static final String PASS = "123456";

	public static void main(String[] args) {
		Connection conn = null;
		Statement stmt = null;
		try {
			// 注册驱动
			Class.forName("com.mysql.jdbc.Driver");

			// 打开连接
			System.out.println("Connecting to database...");
			conn = DriverManager.getConnection(DB_URL, USER, PASS);

			System.out.println("Creating statement...");
			stmt = conn.createStatement();
			
			String sql = "UPDATE person set name='dapeng2' WHERE personid=80";

			Boolean ret = stmt.execute(sql);
			System.out.println("Return value is : " + ret.toString());

			int rows = stmt.executeUpdate(sql);
			System.out.println("Rows impacted : " + rows);

			String sqlQuery;
			sqlQuery = "select personid, name from person;";
			ResultSet rs = stmt.executeQuery(sqlQuery);

			// 从返回值中获取结果
			while (rs.next()) {
				// Retrieve by column name
				long id = rs.getLong("personid");
				String name = rs.getString("name");

				System.out.print("ID: " + id);
				System.out.println(", Name: " + name);
			}
			// 关闭结果集
			rs.close();
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// finally 中关闭资源，包括：Statement和连接
			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException se2) {
			}
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
		System.out.println("end!");
	}

}

