// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.jdbc.second;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CallableStatmentExample {

	// JDBC 驱动和访问url
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/template";

	// 数据库用户名和密码
	static final String USER = "root";
	static final String PASS = "123456";

	public static void main(String[] args) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			// 注册驱动
			Class.forName("com.mysql.jdbc.Driver");

			// 打开连接
			System.out.println("Connecting to database...");
			conn = DriverManager.getConnection(DB_URL, USER, PASS);

			System.out.println("Creating statement...");
			String sql = "{call getPersonName (?, ?)}";
			stmt = conn.prepareCall(sql);

			int personID = 80;
			stmt.setInt(1, personID); 
			stmt.registerOutParameter(2, java.sql.Types.VARCHAR);

			System.out.println("Executing stored procedure...");
			stmt.execute();

			String name = stmt.getString(2);
			System.out.println("Person Name with ID:" + personID + " is " + name);
			stmt.close();
			conn.close();
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// finally 中关闭资源，包括：Statement和连接
			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException se2) {
			}
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
		System.out.println("end!");
	}
}
