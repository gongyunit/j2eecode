// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.mych;

import java.util.List;
import com.test.model.Person;

public interface PerChMapper {
	
	List<Person> getPerson(Person perosn);
}
