// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.mapper;

import java.util.List;
import com.test.model.Child;
import com.test.model.Person;

public interface PersonMapper {
	
	Person getPersonById(int personid);
	List<Child> getChildByPerson(int personid);
}
