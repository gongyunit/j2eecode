// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.myfe;

import java.util.ArrayList;
import java.util.List;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.test.model.Person;

public class MyBatisMain {

	private static ApplicationContext ctx;

	static {
		ctx = new ClassPathXmlApplicationContext("config/applicationContext.xml");
	}

	public static void main(String[] args) {
		PerFeMapper perFeMapper = (PerFeMapper) ctx.getBean("perFeMapper");
		
		Person person = new Person();
		person.setId(4);
		person.setPersonname("per");
		
		List idlist = new ArrayList<Integer>();   
		idlist.add(1);   
		idlist.add(3);  
		
		List<Person> persons = perFeMapper.getPerson(idlist);
		
		System.out.println("=============================================");
		for (Person pp : persons) {
			System.out.println("person name: "+pp.getPersonname());
		}
	}
}
