// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.main;

import java.util.List;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.test.mapper.PersonMapper;
import com.test.model.Child;
import com.test.model.Person;

public class MyBatisMain {

	private static ApplicationContext ctx;

	static {
		ctx = new ClassPathXmlApplicationContext("config/applicationContext.xml");
	}

	public static void main(String[] args) {
		PersonMapper personMapper = (PersonMapper) ctx.getBean("personMaper");
		Person person = personMapper.getPersonById(1);
		System.out.println("person name: "+person.getPersonname());
		
		System.out.println("=============================================");
		List<Child> childs = personMapper.getChildByPerson(person.getId());

		for (Child child : childs) {
			System.out.println("child name: "+child.getChildname() );
		}
	}
}
