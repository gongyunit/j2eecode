// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.mytr;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.test.model.Person;

public class MyBatisMain {

	private static ApplicationContext ctx;

	static {
		ctx = new ClassPathXmlApplicationContext("config/applicationContext.xml");
	}

	public static void main(String[] args) {
		PerTrMapper perTrMapper = (PerTrMapper) ctx.getBean("perTrMapper");
		
		Person person = new Person();
		person.setId(2);
		person.setPersonname("更换personname6999");
		perTrMapper.updatePerson(person);
		
		Person person2 = new Person();
		person2.setId(4);
		person2.setPersonname("per");
		List<Person> persons = perTrMapper.getPerson(person2);
		
		System.out.println("=============================================");
		for (Person pp : persons) {
			System.out.println("person name: "+pp.getPersonname());
		}
		
	}
}
