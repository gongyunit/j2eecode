// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.myset;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.test.model.Person;

public class MyBatisMain {

	private static ApplicationContext ctx;

	static {
		ctx = new ClassPathXmlApplicationContext("config/applicationContext.xml");
	}

	public static void main(String[] args) {
		PerSetMapper perSetMapper = (PerSetMapper) ctx.getBean("perSetMapper");
		
		Person person = new Person();
		person.setId(2);
		person.setPersonname("更换personname2");
		perSetMapper.updatePerson(person);
		
	}
}
