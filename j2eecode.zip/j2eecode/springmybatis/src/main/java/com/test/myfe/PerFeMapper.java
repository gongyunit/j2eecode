// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.myfe;

import java.util.List;
import com.test.model.Person;

public interface PerFeMapper {
	
	List<Person> getPerson(List<Integer> idlist);
}
