// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.model;

import java.util.List;

public class Student {

	private long id;
	
	private String studentname;
	
	private List<Course> clist;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}


	public List<Course> getClist() {
		return clist;
	}

	public void setClist(List<Course> clist) {
		this.clist = clist;
	}

	public String getStudentname() {
		return studentname;
	}

	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}

}
