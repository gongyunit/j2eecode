// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.ch03;

import java.io.Reader;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.test.model.Catalog;
import com.test.model.Course;

public class TestOneToOne {

	private static SqlSessionFactory sqlSessionFactory;
	private static Reader reader;

	static {
		try {
			reader = Resources.getResourceAsReader("config/ch03/Configure.xml");
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		SqlSession session = sqlSessionFactory.openSession();
		try {
			Course c = session.selectOne("com.test.ch03.CourseMapper.getCourse", 3);
			System.out.println("coursename: " +  c.getCoursename());
			
			Catalog catalog = c.getCatalog();
			System.out.println("catalogname: " + catalog.getCatalogname());

		} finally {
			session.close();
		}
	}

}
