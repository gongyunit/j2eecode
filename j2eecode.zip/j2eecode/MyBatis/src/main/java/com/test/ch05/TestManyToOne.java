// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.ch05;

import java.io.Reader;
import java.util.List;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.test.model.Mobile;
import com.test.model.Student;

public class TestManyToOne {

	private static SqlSessionFactory sqlSessionFactory;
	private static Reader reader;

	static {
		try {
			reader = Resources.getResourceAsReader("config/ch05/Configure.xml");
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		SqlSession session = sqlSessionFactory.openSession();
		try {
			Mobile m = session.selectOne("com.test.ch05.MobileMapper.getMobile", 1);
			System.out.println("mobilename: " +  m.getMobilename());
			
			Student student = m.getStudent();
			System.out.println("studentname: " + student.getStudentname());

		} finally {
			session.close();
		}
	}

}
