// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.model;

public class TeacherClassRelation {

	private long teacherid;
	
	private long classinfoid;

	public long getTeacherid() {
		return teacherid;
	}

	public void setTeacherid(long teacherid) {
		this.teacherid = teacherid;
	}

	public long getClassinfoid() {
		return classinfoid;
	}

	public void setClassinfoid(long classinfoid) {
		this.classinfoid = classinfoid;
	}

	
}
