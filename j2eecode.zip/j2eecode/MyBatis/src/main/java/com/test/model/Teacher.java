// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.model;

import java.util.List;

public class Teacher {

	private long id;
	
	private String teachername;
	
	private List<ClassInfo> classinfo;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTeachername() {
		return teachername;
	}

	public void setTeachername(String teachername) {
		this.teachername = teachername;
	}

	public List<ClassInfo> getClassinfo() {
		return classinfo;
	}

	public void setClassinfo(List<ClassInfo> classinfo) {
		this.classinfo = classinfo;
	}
	
	
}
