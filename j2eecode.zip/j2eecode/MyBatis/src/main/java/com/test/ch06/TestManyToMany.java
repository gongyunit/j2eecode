// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.ch06;

import java.io.Reader;
import java.util.List;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import com.test.model.ClassInfo;
import com.test.model.Teacher;

public class TestManyToMany {

	private static SqlSessionFactory sqlSessionFactory;
	private static Reader reader;

	static {
		try {
			reader = Resources.getResourceAsReader("config/ch06/Configure.xml");
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		SqlSession session = sqlSessionFactory.openSession();
		try {
			ClassInfo c = session.selectOne("com.test.ch06.ClassInfoMapper.getClassInfo", 1);
			System.out.println("ClassInfoname: " + c.getClassname());
			
			List<Teacher> teachers = c.getTeacher();
			for(Teacher teacher:teachers){
				System.out.println("Teachername: " + teacher.getTeachername());
			}

		} finally {
			session.close();
		}
	}

}
