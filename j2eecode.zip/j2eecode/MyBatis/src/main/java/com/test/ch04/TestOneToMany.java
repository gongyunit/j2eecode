// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.ch04;

import java.io.Reader;
import java.util.List;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.test.model.Course;
import com.test.model.Student;

public class TestOneToMany {

	private static SqlSessionFactory sqlSessionFactory;
	private static Reader reader;

	static {
		try {
			reader = Resources.getResourceAsReader("config/ch04/Configure.xml");
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		SqlSession session = sqlSessionFactory.openSession();
		try {
			Student student = session.selectOne("com.test.ch04.StudentMapper.getStudent", 1);
			System.out.println("studentname: " + student.getStudentname());
			System.out.println("course size: " + student.getClist().size());
			
			List<Course> courses = student.getClist();
			for (Course c : courses) {
				System.out.println("coursename: " + c.getCoursename());
			}
		} finally {
			session.close();
		}
	}

}
