// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.ch02;

import java.io.Reader;
import java.util.List;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.test.ch01.Person;

public class TestAllMain {
	private static SqlSessionFactory sqlSessionFactory;
	private static Reader reader;
	private static SqlSession session ;

	static {
		try {
			reader = Resources.getResourceAsReader("config/ch02/Configure.xml");
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
		    session = sqlSessionFactory.openSession();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static SqlSessionFactory getSession() {
		return sqlSessionFactory;
	}

	public static void main(String[] args) {
		try {
			getPersons();
			testInsert();
			testUpdate();
			testDelete();
		} finally {
			session.close();
		}
	}

	public static void testInsert() {
		try {
			System.out.println();
			System.out.println("Test insert start...");
			Person person = new Person();
			person.setPersonid(33l);
			person.setName("pp33");
			person.setAge(22);
			person.setSex(1);
			session.insert("insertPerson", person);
			session.commit();
			System.out.println("Test insert finished...");
			
			System.out.println();
			System.out.println("After insert query persons");
			getPersons();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void getPersons() {
		try {
			System.out.println("Test Get start...");
			List<Person> plist = session.selectList("getPersons");
			printPersons(plist);
			System.out.println("Test Get finished...");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void testUpdate() {
		try {
			System.out.println();
			System.out.println("Test update start...");
			Person person = new Person();
			person.setPersonid(33l);
			person.setName("pp33update");
			session.update("updatePerson", person);
			session.commit();
			System.out.println("Test update finished...");

			System.out.println();
			System.out.println("After update");
			getPersons();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void testDelete() {
		try {
			System.out.println();
			System.out.println("Test delete start...");
			session.delete("deletePerson", 33);
			session.commit();
			System.out.println("Test delete finished...");

			System.out.println();
			System.out.println("After delete");
			getPersons();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void printPersons(final List<Person> persons) {
		int count = 0;
		for (Person person : persons) {
			System.out.println("============= Person====="+(++count)+  "============");
			System.out.println("Person Id: " + person.getPersonid());
			System.out.println("Person Name: " + person.getName());
			System.out.println("Person age: " + person.getAge());
			System.out.println("Person sex: " + person.getSex());
		}
	}

}
