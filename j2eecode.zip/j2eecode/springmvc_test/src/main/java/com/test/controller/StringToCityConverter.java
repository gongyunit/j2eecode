// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.controller;

import org.springframework.core.convert.converter.Converter;

import com.test.model.City;

public class StringToCityConverter implements Converter<String, City>{

	@Override
	public City convert(String enumValueStr) {
		
      String value = enumValueStr.trim();
       if (value.isEmpty()) {
           return null;
        }
       
        return City.get(Integer.valueOf(value));
	}

}
