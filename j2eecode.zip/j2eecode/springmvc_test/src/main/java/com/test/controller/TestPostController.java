// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.test.model.Person;
import com.test.util.JacksonUtil;

@Controller
//在类名上加如下value，代表访问此控制器里的方法时，请求链接中都要增加一个tpost.比如访问方法returnMessage，链接就是：../tpost/temp
@RequestMapping(value = "tpost")
public class TestPostController {
	
	//此方法的目的是接受请求，跳转到某个界面
	@RequestMapping(value = "/temp")
    public String returnMessage(Model model) {
        return "tpost";
    }

	//此方法的目的是接受用户的post的请求和json数据，并进行处理
	@RequestMapping(value = "/add",  method=RequestMethod.POST)
    public @ResponseBody Person addPerson(@RequestBody String addinfo){
		Person p = new Person();
		p = (Person)JacksonUtil.parseStringToObject(addinfo, Person.class);
		System.out.println(p.getName());

		p.setId(55l);
		return p;
    }
}
