// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value = "tget")
public class TestGetController {

	//测试get请求，并通过ModelAndView返回界面和数据
    @RequestMapping(value="/way1",method=RequestMethod.GET)  
    public ModelAndView way1(){  
    	//此构造函数就是为了告知返回的界面
        ModelAndView modelAndView = new ModelAndView("/tget1");  
        modelAndView.addObject("message", "Test SpringMvc Get and ModelAndView");  
        return modelAndView;  
    }  
    
	//测试get请求，并通过@ResponseBody返回数据,不能同时配置返回界面
	@RequestMapping(value = "/way2",  method=RequestMethod.GET)
    public @ResponseBody String returnMessage(Model model) {
		String info = "Test spring mvc and @ResponseBody"; 
        return info;
         
    }
}
