// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.util;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JacksonUtil {
	
	//将一个json数据转化为对象
	public static <T> T parseStringToObject(String jackson, Class<T> clazz) {
		if(jackson!=null && !"".equals(jackson)){
			ObjectMapper objectMapper = new ObjectMapper();
			objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);  
			try {
				return objectMapper.readValue(jackson, clazz);
			} catch (Exception e) {
				throw new RuntimeException("parse jackson to object failed!", e);
			}
		}
		return null;
	}
	
     //将输入得Object转换为Json输出
    public static String parseObjectToLightString(Object obj) {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setSerializationInclusion(Include.NON_NULL);
        try {
            return objectMapper.writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException("parse jackson to object failed!", e);
        }
    }

}
