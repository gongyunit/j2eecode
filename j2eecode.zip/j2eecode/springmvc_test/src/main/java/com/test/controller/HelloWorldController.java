// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
 
@Controller
public class HelloWorldController {
 
	@RequestMapping(value = "/hello",  method=RequestMethod.GET)
    public String returnMessage(Model model) {
         
        model.addAttribute("message", "Test spring mvc");
         
        return "hello";
         
    }
 
}
