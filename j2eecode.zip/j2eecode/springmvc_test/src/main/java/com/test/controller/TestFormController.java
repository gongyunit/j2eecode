// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.test.model.Student;

@Controller
@RequestMapping(value = "tform")
public class TestFormController {
	
	@RequestMapping(value = "/temp")
    public ModelAndView returnMessage(Model model) {
		System.out.println("tform  test  temp");
		 return new ModelAndView("tform", "command", new Student());
    }

	
	   @RequestMapping(value = "/add", method = RequestMethod.POST)
	   public String addPerson(@ModelAttribute Student student, ModelMap model) {
	      model.addAttribute("studentname", student.getStudentname());
	      model.addAttribute("password", student.getPassword());
	      model.addAttribute("address", student.getAddress());
	      model.addAttribute("alone", student.isAlone());
	      model.addAttribute("loveCourse", student.getLoveCourse());
	      model.addAttribute("gender", student.getGender());
	      model.addAttribute("loveNumber", student.getLoveNumber());
	      model.addAttribute("city", student.getCity().getValue());
	      return "result";
	   }
	   
	   @ModelAttribute("loveCourse")
	   public List<String> getLoveCourse()
	   {
	      List<String> loveCourse = new ArrayList<String>();
	      loveCourse.add("高数");
	      loveCourse.add("计算机");
	      loveCourse.add("音乐");
	      return loveCourse;
	   }
	   
	   @ModelAttribute("loveNumber")
	   public List<String> getLoveNumber()
	   {
	      List<String> loveNumber = new ArrayList<String>();
	      loveNumber.add("2");
	      loveNumber.add("3");
	      loveNumber.add("6");
	      loveNumber.add("8");
	      return loveNumber;
	   }
	   
	   
	   @ModelAttribute("cityList")
	   public Map<String, String> getCityList()
	   {
	      Map<String, String> cityList = new HashMap<String, String>();
	      cityList.put("0", "成都");
	      cityList.put("1", "上海");
	      cityList.put("2", "贵阳");
	      return cityList;
	   }
	
}
