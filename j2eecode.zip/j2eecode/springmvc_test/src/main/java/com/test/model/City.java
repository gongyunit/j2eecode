// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.model;

public enum City {

    CD("成都",0),
    
    SH("上海",1), 
    
    GY("贵阳",2);
    
    private String value;

    private int index;

    private City(String value, int index) {
        this.value = value;
        this.index = index;
    }
    
    public  static City get(String value){
        for (City p : City.values()) {
            if (p.getValue().equals(value)) {
                return p;
            }
        }
        return null;
    }
    
    public  static City get(int index){
        for (City p : City.values()) {
            if (p.getIndex() == index) {
                return p;
            }
        }
        return null;
    }

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}
}
