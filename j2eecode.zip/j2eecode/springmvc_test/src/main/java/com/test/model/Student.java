// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.model;

public class Student {

    private String studentname;
    private String password;
    private String address;
    private boolean alone;
    private String [] loveCourse;   
    private String gender;
    private String loveNumber;
    private City city;
    
	public String getStudentname() {
		return studentname;
	}
	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}

	public String[] getLoveCourse() {
		return loveCourse;
	}
	public void setLoveCourse(String[] loveCourse) {
		this.loveCourse = loveCourse;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getLoveNumber() {
		return loveNumber;
	}
	public void setLoveNumber(String loveNumber) {
		this.loveNumber = loveNumber;
	}
	public boolean isAlone() {
		return alone;
	}
	public void setAlone(boolean alone) {
		this.alone = alone;
	}
	public City getCity() {
		return city;
	}
	public void setCity(City city) {
		this.city = city;
	}

}
