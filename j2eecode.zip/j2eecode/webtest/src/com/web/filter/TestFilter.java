// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.web.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class TestFilter implements Filter {
	public TestFilter() {
	}

	public void destroy() {
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		//只在控制台打印一句话
		System.out.println("过滤器已拦截住请求");

		//把请求再传回过滤链
		chain.doFilter(request, response);
	}

	public void init(FilterConfig fConfig) throws ServletException {
		//获取web.xml中配置的参数的数值
		String site = fConfig.getInitParameter("name");
		System.out.println("打印过滤器配置的初始化参数: " + site);

	}

}
