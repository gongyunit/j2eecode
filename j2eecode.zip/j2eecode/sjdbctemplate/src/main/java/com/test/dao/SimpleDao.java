// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.dao;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;

public class SimpleDao {
	private JdbcTemplate jdbcTemplate;
	
	public void test() {  
        String sql = "select * from person " ;  
        SqlRowSet sqlRowSet = jdbcTemplate.queryForRowSet(sql);  
        while(sqlRowSet.next()) {  
            System.out.println(sqlRowSet.getLong(1) + "," + sqlRowSet.getString(2));  
        }  
    }  

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
}
