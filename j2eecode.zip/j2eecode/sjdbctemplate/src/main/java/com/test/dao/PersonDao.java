// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.test.pojo.Person;

public class PersonDao {
	private JdbcTemplate jdbcTemplate;
	
	
    /**   
    * 创建表  
    */   
   public void create(String tableName){ 
       jdbcTemplate.execute("create table "+tableName +" (id int(11),name varchar(40),des varchar(40))");  
   } 
	
	//jdbcTemplate.update适合于数据库的insert 、update和delete操作；  
    /**   
     * 第一个参数为执行sql   
     * 第二个参数为参数数据   
     */   
    public void savePerson(Person person) {  
        jdbcTemplate.update("insert into person(personid,name,age,sex) values(?,?,?,?)",   
                new Object[]{person.getPersonid(),person.getName(),person.getAge(),person.getSex()});  
    }  
	
	//jdbcTemplate.update适合于数据库的insert 、update和delete操作；  
    /**   
     * 第一个参数为执行sql   
     * setValues方法中设置参数数据   
     */   
    public void updatePerson(final Person person) {  
        jdbcTemplate.update(  
        		"update person set name=? where personid=?",  
                new PreparedStatementSetter(){  
                	
                    public void setValues(PreparedStatement ps) throws SQLException {  
                        ps.setString(1, person.getName());  
                        ps.setLong(2, person.getPersonid());  
                    }  
                }  
        );  
    }  
    
  
	//jdbcTemplate.update适合于数据库的insert 、update和delete操作；  
    /**   
     * 第一个参数为执行sql   
     * 第二个参数为参数数据   
     * 第三个参数为参数类型
     */  
    public void deletePerson(Person person) {  
        jdbcTemplate.update(  
                "delete from person where personid = ?",   
                new Object[]{person.getPersonid()},   
                new int[]{java.sql.Types.BIGINT});  
    }  
	
    //基于BeanPropertyRowMapper的query查询，针对数据库中的数据跟对象正好是一一映射
    /**   
     * 第一个参数为执行sql   
     * 第二个参数为参数数据   
     * 第三个参数为参数类型
     * 第四个参数为利用BeanPropertyRowMapper将数据库中的数据直接映射成对象
     */
    public List<Person> queryForList1(String nameLike) {  
    	
        return (List<Person>) jdbcTemplate.query("select * from person where name like ?",  
                            new Object[]{nameLike},  
                            new int[]{java.sql.Types.VARCHAR},  
                            new BeanPropertyRowMapper<Person>(Person.class));  
    }  
	
    //基于RowMapper的query查询，针对数据库中的数据跟对象不是一一映射，比如数据库中是数字，对象中是枚举
    /**   
     * 第一个参数为执行sql   
     * 第二个参数为参数数据   
     * 第三个参数为参数类型
     * 第四个参数为利用RowMapper对查询出来每一条数据进行处理，让数据库中的数据跟对象有个映射
     */
	@SuppressWarnings("unchecked")  
    public List<Person> queryForList2(String nameLike) {  
		final List<Person> plist = new ArrayList<Person>();
    	String sql = "select * from person where name like ?";
            jdbcTemplate.query(sql,   
               new Object[]{nameLike},   
               new int[]{java.sql.Types.VARCHAR},   
               new RowMapper(){  
        	   
                   public Object mapRow(ResultSet rs, int rowNum) throws SQLException {  
                   	Person person  = new Person();  
                   	person.setPersonid(rs.getLong("personid"));
                   	person.setName(rs.getString("name"));
                   	plist.add(person);
                    return person;  
                   }  
           });  
           return plist;
       } 

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
}
