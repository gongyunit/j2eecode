// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.test.main;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.test.dao.PersonDao;
import com.test.dao.SimpleDao;
import com.test.pojo.Person;

public class SpringJdbcMain {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		SimpleDao simpleDao = (SimpleDao) context.getBean("simpleDao");
		simpleDao.test();
   
		
		PersonDao personDao = (PersonDao) context.getBean("personDao");
		
		personDao.create("tempTable");
		
		Person testPerson  = new Person();  
		testPerson.setPersonid(11l);
		testPerson.setName("d999");
		testPerson.setAge(22);
		testPerson.setSex(1);
		personDao.savePerson(testPerson);
		personDao.updatePerson(testPerson);
		personDao.deletePerson(testPerson);
		
		List<Person> plist = personDao.queryForList1("%d%");
		for(Person one:plist){
			System.out.println(one.getPersonid());
			System.out.println(one.getName());
		}
	}

}
